﻿using System.Text.Json;
using MunicipalServiceApp.Models;

namespace MunicipalServiceApp.Data
{
    /// <summary>
    /// Core event management and data structures engine.
    /// Implements:
    /// 1. Stacks (Search history & undo), Queues (Announcement ticker FIFO), Priority Queues (Urgent municipal alerts & recommendations)
    /// 2. Sorted Dictionaries (Chronological date ordering), Dictionaries (O(1) category lookup & ID index)
    /// 3. Sets (Unique categories, unique event dates, tag intersections, bookmarked events)
    /// </summary>
    public class EventManager
    {
        // =========================================================================
        // 1. ADVANCED DATA STRUCTURES
        // =========================================================================

        // --- Stacks, Queues, Priority Queues (15 Marks) ---
        private readonly Stack<SearchQuery> _searchHistoryStack = new();
        private readonly Stack<int> _viewHistoryStack = new();
        private readonly Queue<EventItem> _announcementQueue = new();
        private readonly PriorityQueue<EventItem, int> _urgentAlertsPriorityQueue = new();

        // --- Sorted Dictionaries, Dictionaries, Hash Tables (15 Marks) ---
        // Chronological event indexing: Red-Black Tree maintains dates in ascending order
        private readonly SortedDictionary<DateTime, List<EventItem>> _eventsByDate = new();
        // O(1) Category hash table index
        private readonly Dictionary<string, List<EventItem>> _eventsByCategory = new(StringComparer.OrdinalIgnoreCase);
        // O(1) Primary key hash table index
        private readonly Dictionary<int, EventItem> _eventsById = new();
        // User preference frequency maps
        private readonly Dictionary<string, int> _categorySearchCounts = new(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, int> _tagSearchCounts = new(StringComparer.OrdinalIgnoreCase);

        // --- Sets (10 Marks) ---
        private readonly HashSet<string> _uniqueCategories = new(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<DateTime> _uniqueEventDates = new();
        private readonly HashSet<int> _bookmarkedEventIds = new();
        private readonly HashSet<int> _viewedEventIds = new();

        // Master list and state
        private readonly List<EventItem> _allEvents = new();
        private int _nextId = 1;
        private int _totalSearchesCount = 0;
        private readonly string _filePath;

        private static readonly JsonSerializerOptions JsonOpts = new()
        {
            WriteIndented = true
        };

        // =========================================================================
        // CONSTRUCTOR & PERSISTENCE
        // =========================================================================

        public EventManager()
        {
            string appDataFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "MunicipalServiceApp");

            Directory.CreateDirectory(appDataFolder);
            _filePath = Path.Combine(appDataFolder, "events.json");

            LoadFromFile();
        }

        // =========================================================================
        // DATA POPULATION & INDEXING
        // =========================================================================

        public void AddEvent(EventItem item, bool persist = true)
        {
            if (item.Id <= 0)
            {
                item.Id = _nextId++;
            }
            else if (item.Id >= _nextId)
            {
                _nextId = item.Id + 1;
            }

            _allEvents.Add(item);

            // Index in Dictionary by Id (O(1))
            _eventsById[item.Id] = item;

            // Index in SortedDictionary by Date (O(log N))
            DateTime dateKey = item.EventDate.Date;
            if (!_eventsByDate.TryGetValue(dateKey, out var dateList))
            {
                dateList = new List<EventItem>();
                _eventsByDate[dateKey] = dateList;
            }
            dateList.Add(item);

            // Index in Dictionary by Category (O(1))
            if (!string.IsNullOrWhiteSpace(item.Category))
            {
                if (!_eventsByCategory.TryGetValue(item.Category, out var catList))
                {
                    catList = new List<EventItem>();
                    _eventsByCategory[item.Category] = catList;
                }
                catList.Add(item);

                // Add to unique categories Set
                _uniqueCategories.Add(item.Category.Trim());
            }

            // Add to unique event dates Set
            _uniqueEventDates.Add(dateKey);

            // Populate Announcement FIFO Queue if announcement
            if (item.IsAnnouncement)
            {
                _announcementQueue.Enqueue(item);
            }

            // Populate Urgent Alerts PriorityQueue
            // PriorityQueue is min-heap: 1 = Critical (highest priority), 4 = Low
            int priorityRank = item.Priority switch
            {
                EventPriority.Critical => 1,
                EventPriority.High => 2,
                EventPriority.Medium => 3,
                _ => 4
            };
            _urgentAlertsPriorityQueue.Enqueue(item, priorityRank);

            if (persist)
            {
                SaveToFile();
            }
        }

        // =========================================================================
        // STACKS (Search History & Navigation)
        // =========================================================================

        public void PushSearchQuery(SearchQuery query)
        {
            _searchHistoryStack.Push(query);
            _totalSearchesCount++;

            // Track category search frequency
            if (!string.IsNullOrWhiteSpace(query.Category) && query.Category != "All Categories")
            {
                _categorySearchCounts[query.Category] = _categorySearchCounts.GetValueOrDefault(query.Category, 0) + 1;
            }

            // Track keyword/tag search frequency
            if (!string.IsNullOrWhiteSpace(query.Keyword))
            {
                var words = query.Keyword.Split(new[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var word in words)
                {
                    string clean = word.Trim().ToLowerInvariant();
                    if (clean.Length > 2)
                    {
                        _tagSearchCounts[clean] = _tagSearchCounts.GetValueOrDefault(clean, 0) + 1;
                    }
                }
            }
        }

        public bool CanUndoSearch => _searchHistoryStack.Count > 1;

        public SearchQuery? PopPreviousSearch()
        {
            if (_searchHistoryStack.Count <= 1) return null;
            _searchHistoryStack.Pop(); // Remove current search
            return _searchHistoryStack.Peek(); // Return previous
        }

        public IReadOnlyList<SearchQuery> GetSearchHistory() => _searchHistoryStack.ToArray();

        public void PushViewHistory(int eventId)
        {
            _viewHistoryStack.Push(eventId);
            _viewedEventIds.Add(eventId);

            if (_eventsById.TryGetValue(eventId, out var item))
            {
                if (!string.IsNullOrWhiteSpace(item.Category))
                {
                    _categorySearchCounts[item.Category] = _categorySearchCounts.GetValueOrDefault(item.Category, 0) + 1;
                }
                foreach (var tag in item.Tags)
                {
                    _tagSearchCounts[tag] = _tagSearchCounts.GetValueOrDefault(tag, 0) + 1;
                }
            }
        }

        public int? PopViewHistory()
        {
            if (_viewHistoryStack.Count <= 1) return null;
            _viewHistoryStack.Pop();
            return _viewHistoryStack.Peek();
        }

        // =========================================================================
        // QUEUES & PRIORITY QUEUES
        // =========================================================================

        public IReadOnlyList<EventItem> GetAnnouncementQueue() => _announcementQueue.ToArray();

        public EventItem? DequeueAnnouncement()
        {
            if (_announcementQueue.Count == 0) return null;
            return _announcementQueue.Dequeue();
        }

        public EventItem? RotateAnnouncementQueue()
        {
            if (_announcementQueue.Count == 0) return null;
            var current = _announcementQueue.Dequeue();
            _announcementQueue.Enqueue(current);
            return current;
        }

        public List<EventItem> GetUrgentNoticesOrdered()
        {
            // Clone priority queue to extract all items in priority order without emptying original
            var copy = new PriorityQueue<EventItem, int>();
            foreach (var ev in _allEvents)
            {
                int rank = ev.Priority switch
                {
                    EventPriority.Critical => 1,
                    EventPriority.High => 2,
                    EventPriority.Medium => 3,
                    _ => 4
                };
                copy.Enqueue(ev, rank);
            }

            var result = new List<EventItem>();
            while (copy.Count > 0)
            {
                result.Add(copy.Dequeue());
            }
            return result;
        }

        // =========================================================================
        // SORTED DICTIONARIES & DICTIONARY RETRIEVAL
        // =========================================================================

        /// <summary>
        /// Retrieves events in a date range using the SortedDictionary.
        /// Exploits chronological sorting of keys for fast range scanning.
        /// </summary>
        public List<EventItem> GetEventsByDateRange(DateTime start, DateTime end)
        {
            var results = new List<EventItem>();
            DateTime startDate = start.Date;
            DateTime endDate = end.Date;

            foreach (var kvp in _eventsByDate)
            {
                if (kvp.Key >= startDate && kvp.Key <= endDate)
                {
                    results.AddRange(kvp.Value);
                }
                else if (kvp.Key > endDate)
                {
                    // Since SortedDictionary is sorted ascending, we can stop early!
                    break;
                }
            }
            return results;
        }

        /// <summary>
        /// Retrieves events by category using the O(1) category dictionary.
        /// </summary>
        public List<EventItem> GetEventsByCategory(string category)
        {
            if (string.IsNullOrWhiteSpace(category) || category.Equals("All Categories", StringComparison.OrdinalIgnoreCase))
            {
                return new List<EventItem>(_allEvents);
            }

            if (_eventsByCategory.TryGetValue(category, out var list))
            {
                return new List<EventItem>(list);
            }

            return new List<EventItem>();
        }

        public EventItem? GetEventById(int id)
        {
            _eventsById.TryGetValue(id, out var ev);
            return ev;
        }

        // =========================================================================
        // SETS OPERATIONS
        // =========================================================================

        public HashSet<string> UniqueCategories => new(_uniqueCategories, StringComparer.OrdinalIgnoreCase);

        public HashSet<DateTime> UniqueEventDates => new(_uniqueEventDates);

        public bool HasEventOnDate(DateTime date) => _uniqueEventDates.Contains(date.Date);

        public bool IsBookmarked(int eventId) => _bookmarkedEventIds.Contains(eventId);

        public void ToggleBookmark(int eventId)
        {
            if (_bookmarkedEventIds.Contains(eventId))
                _bookmarkedEventIds.Remove(eventId);
            else
                _bookmarkedEventIds.Add(eventId);
        }

        public HashSet<int> BookmarkedEventIds => new(_bookmarkedEventIds);

        // =========================================================================
        // SEARCH ENGINE (Combining Data Structures)
        // =========================================================================

        public List<EventItem> SearchEvents(string? keyword, string? category, DateTime? startDate, DateTime? endDate)
        {
            IEnumerable<EventItem> source = _allEvents;

            // 1. Category filter using Hash Table (O(1)) if specified
            if (!string.IsNullOrWhiteSpace(category) && !category.Equals("All Categories", StringComparison.OrdinalIgnoreCase))
            {
                if (_eventsByCategory.TryGetValue(category, out var catEvents))
                {
                    source = catEvents;
                }
                else
                {
                    source = Enumerable.Empty<EventItem>();
                }
            }

            // 2. Date Range filter using SortedDictionary
            if (startDate.HasValue || endDate.HasValue)
            {
                DateTime from = startDate?.Date ?? DateTime.MinValue.Date;
                DateTime to = endDate?.Date ?? DateTime.MaxValue.Date;
                var dateMatching = new HashSet<int>(GetEventsByDateRange(from, to).Select(e => e.Id));
                source = source.Where(e => dateMatching.Contains(e.Id));
            }

            // 3. Keyword / Text search with tag matching
            if (!string.IsNullOrWhiteSpace(keyword))
            {
                string term = keyword.Trim().ToLowerInvariant();
                source = source.Where(e =>
                    e.Title.ToLowerInvariant().Contains(term) ||
                    e.Description.ToLowerInvariant().Contains(term) ||
                    e.Location.ToLowerInvariant().Contains(term) ||
                    e.Organizer.ToLowerInvariant().Contains(term) ||
                    e.Tags.Any(t => t.ToLowerInvariant().Contains(term)));
            }

            var results = source.OrderBy(e => e.EventDate).ThenBy(e => e.Priority).ToList();

            // Record query in Stack
            var query = new SearchQuery
            {
                Keyword = keyword ?? string.Empty,
                Category = category ?? "All Categories",
                StartDate = startDate,
                EndDate = endDate,
                ResultCount = results.Count,
                Timestamp = DateTime.Now
            };
            PushSearchQuery(query);

            return results;
        }

        // =========================================================================
        // USER PREFERENCES & ANALYTICS (FOR RECOMMENDATIONS)
        // =========================================================================

        public int TotalSearchesCount => _totalSearchesCount;

        public IReadOnlyDictionary<string, int> CategorySearchCounts => _categorySearchCounts;

        public IReadOnlyDictionary<string, int> TagSearchCounts => _tagSearchCounts;

        public IReadOnlyList<EventItem> GetAllEvents() => _allEvents.AsReadOnly();

        // =========================================================================
        // FILE PERSISTENCE & SEEDING
        // =========================================================================

        private void SaveToFile()
        {
            try
            {
                string json = JsonSerializer.Serialize(_allEvents, JsonOpts);
                File.WriteAllText(_filePath, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error saving events: {ex.Message}");
            }
        }

        private void LoadFromFile()
        {
            if (File.Exists(_filePath))
            {
                try
                {
                    string json = File.ReadAllText(_filePath);
                    var list = JsonSerializer.Deserialize<List<EventItem>>(json);
                    if (list != null && list.Count > 0)
                    {
                        foreach (var item in list)
                        {
                            AddEvent(item, persist: false);
                        }
                        return;
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Error reading events file: {ex.Message}");
                }
            }

            // Seed with rich sample municipal events if no data exists
            SeedDefaultEvents();
        }

        private void SeedDefaultEvents()
        {
            DateTime today = DateTime.Today;

            var seeds = new List<EventItem>
            {
                new()
                {
                    Title = "Urgent: Water Supply Maintenance Notice",
                    Category = "Water & Infrastructure",
                    EventDate = today.AddDays(1),
                    TimeSlot = "08:00 - 17:00",
                    Location = "Wards 4, 7 & 12 (North District)",
                    Description = "Scheduled pipeline replacement and valve upgrades. Water tankers will be stationed at Central Park and Northgate Primary School during the interruption.",
                    Priority = EventPriority.Critical,
                    IsAnnouncement = true,
                    Organizer = "Municipal Water & Sanitation Department",
                    ContactInfo = "water.helpline@municipality.gov.za",
                    Tags = new() { "water", "infrastructure", "outage", "maintenance", "essential" }
                },
                new()
                {
                    Title = "Annual Community Spring Clean-Up Day",
                    Category = "Sanitation & Environment",
                    EventDate = today.AddDays(3),
                    TimeSlot = "08:30 - 13:00",
                    Location = "Greenfield Community Park & Riverbank",
                    Description = "Join fellow residents, schools, and local businesses in revitalising our public parks and waterways. Gloves, refuse bags, and refreshments provided free of charge.",
                    Priority = EventPriority.Medium,
                    IsAnnouncement = false,
                    Organizer = "Keep Our City Clean Initiative",
                    ContactInfo = "environment@municipality.gov.za",
                    Tags = new() { "environment", "clean-up", "volunteer", "recycling", "parks", "family" }
                },
                new()
                {
                    Title = "Mayor's Public Town Hall & Budget Review",
                    Category = "Town Hall & Governance",
                    EventDate = today.AddDays(5),
                    TimeSlot = "18:00 - 20:30",
                    Location = "City Hall Main Auditorium & Livestream",
                    Description = "Participate in the public consultation session for the 2026/2027 Municipal Integrated Development Plan (IDP) and capital expenditure allocations. Citizen Q&A will be hosted.",
                    Priority = EventPriority.High,
                    IsAnnouncement = false,
                    Organizer = "Office of the Executive Mayor",
                    ContactInfo = "mayor.office@municipality.gov.za",
                    Tags = new() { "governance", "budget", "town-hall", "public", "idp", "council" }
                },
                new()
                {
                    Title = "Free Mobile Health Clinic & Senior Screening",
                    Category = "Health & Social Services",
                    EventDate = today.AddDays(7),
                    TimeSlot = "09:00 - 15:00",
                    Location = "Westville Civic Centre",
                    Description = "Comprehensive preventative health services including blood pressure, glucose, vision screening, and flu vaccinations. Free consultations with municipal nursing staff.",
                    Priority = EventPriority.High,
                    IsAnnouncement = false,
                    Organizer = "Municipal Health Services",
                    ContactInfo = "health.clinics@municipality.gov.za",
                    Tags = new() { "health", "wellness", "seniors", "vaccination", "free", "clinic" }
                },
                new()
                {
                    Title = "Electrical Grid Upgrade & Load Reduction Alert",
                    Category = "Water & Infrastructure",
                    EventDate = today.AddDays(2),
                    TimeSlot = "22:00 - 04:00",
                    Location = "Substations 3B & 4A (Industrial Zone)",
                    Description = "Overnight planned maintenance to replace high-voltage transformers. Backup power supply will be routed where possible. Please switch off sensitive appliances.",
                    Priority = EventPriority.High,
                    IsAnnouncement = true,
                    Organizer = "City Power & Energy Distribution",
                    ContactInfo = "electricity@municipality.gov.za",
                    Tags = new() { "electricity", "power", "grid", "maintenance", "alert" }
                },
                new()
                {
                    Title = "Youth Soccer Tournament & Sports Festival",
                    Category = "Sports & Recreation",
                    EventDate = today.AddDays(8),
                    TimeSlot = "09:00 - 17:00",
                    Location = "Olympia Sports Stadium Complex",
                    Description = "U13, U15 and U17 boys and girls soccer teams competing for the Mayor's Cup. Food stalls, jumping castles for kids, and coaching clinics by national league scouts.",
                    Priority = EventPriority.Low,
                    IsAnnouncement = false,
                    Organizer = "Department of Sports, Arts & Culture",
                    ContactInfo = "sports@municipality.gov.za",
                    Tags = new() { "sports", "soccer", "youth", "recreation", "tournament", "family" }
                },
                new()
                {
                    Title = "Emergency Disaster Preparedness Workshop",
                    Category = "Public Safety & Emergency",
                    EventDate = today.AddDays(10),
                    TimeSlot = "10:00 - 13:00",
                    Location = "Central Fire Station Training Room",
                    Description = "Learn essential first aid, home fire prevention, flood safety precautions, and emergency communication protocols. Hands-on fire extinguisher demonstrations.",
                    Priority = EventPriority.High,
                    IsAnnouncement = false,
                    Organizer = "Disaster Management & Fire Rescue",
                    ContactInfo = "firesafety@municipality.gov.za",
                    Tags = new() { "safety", "fire", "emergency", "first-aid", "preparedness" }
                },
                new()
                {
                    Title = "Local Heritage & Cultural Food Fair",
                    Category = "Community & Culture",
                    EventDate = today.AddDays(12),
                    TimeSlot = "10:00 - 18:00",
                    Location = "Victoria Square Market Promenade",
                    Description = "Celebrating our diverse municipal cultural heritage with over 60 traditional food stalls, indigenous music performances, craft workshops, and storytelling.",
                    Priority = EventPriority.Medium,
                    IsAnnouncement = false,
                    Organizer = "Heritage Tourism Directorate",
                    ContactInfo = "events@municipality.gov.za",
                    Tags = new() { "culture", "food", "heritage", "festival", "music", "arts", "family" }
                },
                new()
                {
                    Title = "Road Resurfacing and Traffic Diversion Notice",
                    Category = "Water & Infrastructure",
                    EventDate = today.AddDays(4),
                    TimeSlot = "07:00 - 16:30",
                    Location = "Main Reef Road between 4th and 11th Avenues",
                    Description = "Milling and asphalt resurfacing operations. Single-lane closures in effect. Motorists are advised to use alternative bypass routes via Riverside Avenue.",
                    Priority = EventPriority.High,
                    IsAnnouncement = true,
                    Organizer = "Municipal Roads & Stormwater Agency",
                    ContactInfo = "roads@municipality.gov.za",
                    Tags = new() { "roads", "traffic", "resurfacing", "infrastructure", "transport" }
                },
                new()
                {
                    Title = "Solar Power & Green Energy Citizen Expo",
                    Category = "Sanitation & Environment",
                    EventDate = today.AddDays(14),
                    TimeSlot = "10:00 - 16:00",
                    Location = "Municipal Exhibition Hall B",
                    Description = "Discover residential solar rebates, small-scale embedded generation tariffs, rainwater harvesting setups, and composting systems. Free consultations with accredited installers.",
                    Priority = EventPriority.Medium,
                    IsAnnouncement = false,
                    Organizer = "Climate & Sustainability Taskforce",
                    ContactInfo = "green.city@municipality.gov.za",
                    Tags = new() { "environment", "solar", "energy", "sustainability", "green", "rebates" }
                },
                new()
                {
                    Title = "Free Rabies Vaccination & Pet Microchipping Clinic",
                    Category = "Health & Social Services",
                    EventDate = today.AddDays(15),
                    TimeSlot = "08:30 - 14:00",
                    Location = "Meadowlands Sports Ground Pavilion",
                    Description = "State veterinary officers and municipal animal control providing compulsory rabies vaccinations and discounted microchipping for dogs and cats. Bring pet health booklets.",
                    Priority = EventPriority.Medium,
                    IsAnnouncement = false,
                    Organizer = "Veterinary Public Health Unit",
                    ContactInfo = "animals@municipality.gov.za",
                    Tags = new() { "pets", "animals", "health", "vaccination", "free", "veterinary" }
                },
                new()
                {
                    Title = "Entrepreneurs & Small Business Support Seminar",
                    Category = "Town Hall & Governance",
                    EventDate = today.AddDays(18),
                    TimeSlot = "09:00 - 14:00",
                    Location = "City Innovation Hub - Boardroom 1",
                    Description = "Guidance on municipal vendor registration, supply chain compliance, tax clearance, and access to provincial enterprise development grants for local startups.",
                    Priority = EventPriority.Medium,
                    IsAnnouncement = false,
                    Organizer = "Local Economic Development (LED) Unit",
                    ContactInfo = "business.led@municipality.gov.za",
                    Tags = new() { "business", "economy", "entrepreneurship", "tenders", "grants" }
                },
                new()
                {
                    Title = "Public Library Digital Literacy Coding Bootcamp",
                    Category = "Community & Culture",
                    EventDate = today.AddDays(20),
                    TimeSlot = "14:00 - 16:30",
                    Location = "Central Library Media Lab",
                    Description = "Free introductory computer skills and coding workshops for high school learners and young adults. Covers basic web design, cyber-safety, and digital career guidance.",
                    Priority = EventPriority.Low,
                    IsAnnouncement = false,
                    Organizer = "City Libraries & Information Services",
                    ContactInfo = "libraries@municipality.gov.za",
                    Tags = new() { "youth", "education", "coding", "library", "technology", "free" }
                },
                new()
                {
                    Title = "Severe Weather & Flash Flood Cautionary Notice",
                    Category = "Public Safety & Emergency",
                    EventDate = today.AddDays(0), // Today
                    TimeSlot = "14:00 - 23:00",
                    Location = "Low-lying river catchment areas across Metro",
                    Description = "Weather bureau warns of severe thunderstorms with risk of localised flash flooding in low-lying bridges and informal settlements. Emergency response teams on high alert.",
                    Priority = EventPriority.Critical,
                    IsAnnouncement = true,
                    Organizer = "Emergency Management Services (EMS)",
                    ContactInfo = "emergency107@municipality.gov.za",
                    Tags = new() { "weather", "flood", "emergency", "alert", "safety", "critical" }
                },
                new()
                {
                    Title = "Community Policing Forum (CPF) Monthly Meeting",
                    Category = "Public Safety & Emergency",
                    EventDate = today.AddDays(6),
                    TimeSlot = "18:30 - 20:00",
                    Location = "Sector 2 Police Station Conference Hall",
                    Description = "Discussion of neighbourhood crime statistics, neighbourhood watch patrols, camera surveillance rollout, and street committee feedback with the Station Commander.",
                    Priority = EventPriority.Medium,
                    IsAnnouncement = false,
                    Organizer = "Community Policing Forum Sector 2",
                    ContactInfo = "cpf.sector2@municipality.gov.za",
                    Tags = new() { "safety", "police", "cpf", "security", "neighbourhood", "meeting" }
                },
                new()
                {
                    Title = "Bulk Waste Collection Week (E-Waste & Furniture)",
                    Category = "Sanitation & Environment",
                    EventDate = today.AddDays(9),
                    TimeSlot = "07:00 - 17:00",
                    Location = "All Suburbs - Scheduled Kerbside Pickup",
                    Description = "Special municipal collection for bulky household goods, broken electronics, discarded mattresses, and tree branches. Place items cleanly on kerbsides by 07:00.",
                    Priority = EventPriority.Medium,
                    IsAnnouncement = true,
                    Organizer = "Waste Management & Pikitup Directorate",
                    ContactInfo = "refuse.pickup@municipality.gov.za",
                    Tags = new() { "waste", "recycling", "refuse", "sanitation", "environment" }
                }
            };

            foreach (var item in seeds)
            {
                AddEvent(item, persist: false);
            }

            SaveToFile();
        }
    }
}

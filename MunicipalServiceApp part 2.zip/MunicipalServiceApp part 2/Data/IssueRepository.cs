using System.Text.Json;
using MunicipalServiceApp.Models;

namespace MunicipalServiceApp.Data
{
    /// <summary>
    /// In-memory repository for IssueReport objects with JSON file persistence.
    /// Provides CRUD operations, statistics, and CSV export capabilities.
    /// </summary>
    public class IssueRepository
    {
        // ── Private state ──────────────────────────────────────────────
        private readonly List<IssueReport> _issues = new();
        private int _nextId = 1;

        // Path to the JSON persistence file stored beside the executable.
        private readonly string _filePath;

        // ── JSON serialiser options ────────────────────────────────────
        private static readonly JsonSerializerOptions _jsonOptions = new()
        {
            WriteIndented = true
        };

        // ── Constructor ────────────────────────────────────────────────
        public IssueRepository()
        {
            // Store issues.json in the application data folder
            string appDataFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "MunicipalServiceApp");

            Directory.CreateDirectory(appDataFolder);
            _filePath = Path.Combine(appDataFolder, "issues.json");

            LoadFromFile();
        }

        // ── Public API ─────────────────────────────────────────────────

        /// <summary>Adds a new issue, assigns an Id, persists to disk.</summary>
        public void AddIssue(IssueReport issue)
        {
            issue.Id = _nextId++;
            issue.SubmissionDate = DateTime.Now;
            issue.Status = "Submitted";
            _issues.Add(issue);
            SaveToFile();
        }

        /// <summary>Returns all stored issues (newest first).</summary>
        public List<IssueReport> GetAllIssues()
        {
            return _issues.OrderByDescending(i => i.SubmissionDate).ToList();
        }

        /// <summary>Returns the total number of issues ever reported.</summary>
        public int TotalReports => _issues.Count;

        /// <summary>Returns the number of issues submitted today.</summary>
        public int TodaysReports =>
            _issues.Count(i => i.SubmissionDate.Date == DateTime.Today);

        /// <summary>
        /// Exports all issues to a CSV file at the specified path.
        /// </summary>
        public void ExportToCsv(string csvPath)
        {
            using var writer = new StreamWriter(csvPath);
            // Header
            writer.WriteLine("Id,Location,Category,Priority,Description,AttachmentPath,ContactPhone,ContactEmail,Status,SubmissionDate");

            foreach (var issue in _issues)
            {
                writer.WriteLine(string.Join(",",
                    Escape(issue.Id.ToString()),
                    Escape(issue.Location),
                    Escape(issue.Category),
                    Escape(issue.Priority),
                    Escape(issue.Description),
                    Escape(issue.AttachmentPath),
                    Escape(issue.ContactPhone),
                    Escape(issue.ContactEmail),
                    Escape(issue.Status),
                    Escape(issue.SubmissionDate.ToString("yyyy-MM-dd HH:mm:ss"))
                ));
            }
        }

        // ── Persistence helpers ────────────────────────────────────────

        private void SaveToFile()
        {
            try
            {
                string json = JsonSerializer.Serialize(_issues, _jsonOptions);
                File.WriteAllText(_filePath, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Save failed: {ex.Message}");
            }
        }

        private void LoadFromFile()
        {
            try
            {
                if (!File.Exists(_filePath)) return;

                string json = File.ReadAllText(_filePath);
                var loaded = JsonSerializer.Deserialize<List<IssueReport>>(json);

                if (loaded is not null && loaded.Count > 0)
                {
                    _issues.AddRange(loaded);
                    _nextId = _issues.Max(i => i.Id) + 1;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Load failed: {ex.Message}");
            }
        }

        /// <summary>CSV-escapes a value by wrapping it in quotes if necessary.</summary>
        private static string Escape(string value)
        {
            if (value.Contains(',') || value.Contains('"') || value.Contains('\n'))
            {
                return $"\"{value.Replace("\"", "\"\"")}\"";
            }
            return value;
        }
    }
}

﻿using MunicipalServiceApp.Data;
using MunicipalServiceApp.Models;

namespace MunicipalServiceApp
{
    /// <summary>
    /// Modal dialog displaying full details of a municipal event or announcement.
    /// Records event view into the EventManager view stack (Stack<int>) and preference tracker.
    /// </summary>
    public class EventDetailsDialog : Form
    {
        private readonly EventItem _item;
        private readonly EventManager _manager;

        public EventDetailsDialog(EventItem item, EventManager manager)
        {
            _item = item;
            _manager = manager;

            // Track view in stack and preferences
            _manager.PushViewHistory(_item.Id);

            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = $"{_item.TypeDisplay}: {_item.Title}";
            this.Size = new Size(620, 560);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = AppTheme.WhiteBg;

            // Top Header Panel
            var pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 90,
                BackColor = AppTheme.PrimaryBlue,
                Padding = new Padding(20, 12, 20, 12)
            };

            var lblBadge = new Label
            {
                Text = $"{_item.TypeDisplay.ToUpper()}  •  {_item.Category.ToUpper()}  •  PRIORITY: {_item.Priority.ToString().ToUpper()}",
                ForeColor = AppTheme.LightBlue,
                Font = AppTheme.SmallBoldFont,
                Dock = DockStyle.Top,
                Height = 22
            };

            var lblTitle = new Label
            {
                Text = _item.Title,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 13.5F, FontStyle.Bold),
                Dock = DockStyle.Fill,
                AutoEllipsis = true
            };

            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Controls.Add(lblBadge);

            // Content Panel
            var pnlBody = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(24)
            };

            int y = 15;

            // Date & Time Card
            var pnlDateTime = CreateInfoCard("📅 Date & Schedule", $"{_item.EventDate:dddd, dd MMMM yyyy}  ({_item.TimeSlot})\nStatus: {(_item.DaysUntil < 0 ? "Past Event" : _item.DaysUntil == 0 ? "TODAY" : $"In {_item.DaysUntil} days")}", ref y, pnlBody);

            // Location Card
            var pnlLocation = CreateInfoCard("📍 Venue / Location", _item.Location, ref y, pnlBody);

            // Description Card
            var pnlDesc = CreateInfoCard("📝 Description & Details", _item.Description, ref y, pnlBody, isLarge: true);

            // Organizer Card
            var pnlOrg = CreateInfoCard("🏛 Organizer & Contact", $"Organized by: {_item.Organizer}\nContact: {_item.ContactInfo}", ref y, pnlBody);

            // Tags Chips
            var lblTagsTitle = new Label
            {
                Text = "🏷 Keywords & Topic Tags:",
                Font = AppTheme.LabelBoldFont,
                ForeColor = AppTheme.DarkText,
                Location = new Point(24, y),
                Size = new Size(540, 22)
            };
            pnlBody.Controls.Add(lblTagsTitle);
            y += 26;

            var flpTags = new FlowLayoutPanel
            {
                Location = new Point(24, y),
                Size = new Size(540, 40),
                AutoScroll = true
            };
            foreach (var tag in _item.Tags)
            {
                var lblTag = new Label
                {
                    Text = $"#{tag}",
                    BackColor = AppTheme.LightBlue,
                    ForeColor = AppTheme.PrimaryBlue,
                    Font = AppTheme.SmallBoldFont,
                    Padding = new Padding(6, 3, 6, 3),
                    Margin = new Padding(0, 0, 6, 6),
                    AutoSize = true
                };
                flpTags.Controls.Add(lblTag);
            }
            pnlBody.Controls.Add(flpTags);
            y += 50;

            // Footer / Button Panel
            var pnlFooter = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 65,
                BackColor = Color.White,
                Padding = new Padding(20, 12, 20, 12)
            };

            var btnBookmark = new Button
            {
                Text = _manager.IsBookmarked(_item.Id) ? "⭐ Bookmarked" : "☆ Bookmark Event",
                Size = new Size(160, 40),
                Dock = DockStyle.Left
            };
            if (_manager.IsBookmarked(_item.Id))
                AppTheme.StyleSuccessButton(btnBookmark);
            else
                AppTheme.StyleSecondaryButton(btnBookmark);

            btnBookmark.Click += (s, e) =>
            {
                _manager.ToggleBookmark(_item.Id);
                bool nowBookmarked = _manager.IsBookmarked(_item.Id);
                btnBookmark.Text = nowBookmarked ? "⭐ Bookmarked" : "☆ Bookmark Event";
                if (nowBookmarked)
                    AppTheme.StyleSuccessButton(btnBookmark);
                else
                    AppTheme.StyleSecondaryButton(btnBookmark);
            };

            var btnClose = new Button
            {
                Text = "Close",
                Size = new Size(120, 40),
                Dock = DockStyle.Right
            };
            AppTheme.StylePrimaryButton(btnClose);
            btnClose.Click += (s, e) => this.Close();

            pnlFooter.Controls.Add(btnBookmark);
            pnlFooter.Controls.Add(btnClose);

            this.Controls.Add(pnlBody);
            this.Controls.Add(pnlHeader);
            this.Controls.Add(pnlFooter);
        }

        private Panel CreateInfoCard(string header, string content, ref int y, Panel parent, bool isLarge = false)
        {
            var pnl = new Panel
            {
                Location = new Point(24, y),
                Size = new Size(540, isLarge ? 110 : 65),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(10)
            };

            var lblH = new Label
            {
                Text = header,
                Font = AppTheme.SmallBoldFont,
                ForeColor = AppTheme.AccentBlue,
                Dock = DockStyle.Top,
                Height = 20
            };

            var lblC = new Label
            {
                Text = content,
                Font = AppTheme.LabelFont,
                ForeColor = AppTheme.DarkText,
                Dock = DockStyle.Fill,
                AutoEllipsis = true
            };

            pnl.Controls.Add(lblC);
            pnl.Controls.Add(lblH);
            parent.Controls.Add(pnl);

            y += (isLarge ? 120 : 75);
            return pnl;
        }
    }
}

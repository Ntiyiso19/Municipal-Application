namespace MunicipalServiceApp
{
    partial class IssuesHistoryForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            pnlHeader = new Panel();
            lblHeader = new Label();
            dgvIssues = new DataGridView();
            btnClose = new Button();

            pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvIssues).BeginInit();
            SuspendLayout();

            // ── pnlHeader ──────────────────────────────────────────────
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Height = 60;
            pnlHeader.BackColor = AppTheme.PrimaryBlue;
            pnlHeader.Padding = new Padding(20, 0, 20, 0);
            pnlHeader.Controls.Add(lblHeader);

            lblHeader.Dock = DockStyle.Fill;
            lblHeader.Text = "📑  Issue History";
            lblHeader.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblHeader.ForeColor = Color.White;
            lblHeader.TextAlign = ContentAlignment.MiddleLeft;

            // ── dgvIssues ──────────────────────────────────────────────
            dgvIssues.Dock = DockStyle.Fill;
            dgvIssues.ReadOnly = true;
            dgvIssues.AllowUserToAddRows = false;
            dgvIssues.AllowUserToDeleteRows = false;
            dgvIssues.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvIssues.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvIssues.BackgroundColor = AppTheme.WhiteBg;
            dgvIssues.BorderStyle = BorderStyle.None;
            dgvIssues.RowHeadersVisible = false;
            dgvIssues.EnableHeadersVisualStyles = false;
            dgvIssues.ColumnHeadersDefaultCellStyle.BackColor = AppTheme.PrimaryBlue;
            dgvIssues.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvIssues.ColumnHeadersDefaultCellStyle.Font = AppTheme.LabelBoldFont;
            dgvIssues.ColumnHeadersHeight = 36;
            dgvIssues.DefaultCellStyle.Font = AppTheme.LabelFont;
            dgvIssues.AlternatingRowsDefaultCellStyle.BackColor = AppTheme.LightBlue;

            // ── btnClose ───────────────────────────────────────────────
            btnClose.Dock = DockStyle.Bottom;
            btnClose.Height = 44;
            btnClose.Text = "Close";
            AppTheme.StyleSecondaryButton(btnClose);
            btnClose.Click += BtnClose_Click;

            // ── IssuesHistoryForm ──────────────────────────────────────
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(900, 500);
            Controls.Add(dgvIssues);
            Controls.Add(btnClose);
            Controls.Add(pnlHeader);
            MinimumSize = new Size(700, 400);
            StartPosition = FormStartPosition.CenterParent;
            Text = "Issue History – Municipal Service Portal";

            pnlHeader.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvIssues).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlHeader;
        private Label lblHeader;
        private DataGridView dgvIssues;
        private Button btnClose;
    }
}

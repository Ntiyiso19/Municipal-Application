using MunicipalServiceApp.Data;

namespace MunicipalServiceApp
{
    /// <summary>
    /// Displays all submitted issues in a DataGridView with
    /// configured columns for easy scanning.
    /// </summary>
    public partial class IssuesHistoryForm : Form
    {
        private readonly IssueRepository _repository;

        public IssuesHistoryForm(IssueRepository repository)
        {
            _repository = repository;
            InitializeComponent();
            ConfigureColumns();
            LoadData();
        }

        /// <summary>Configures the DataGridView columns to match the IssueReport model.</summary>
        private void ConfigureColumns()
        {
            dgvIssues.AutoGenerateColumns = false;
            dgvIssues.Columns.Clear();

            dgvIssues.Columns.AddRange(new DataGridViewColumn[]
            {
                new DataGridViewTextBoxColumn { Name = "Id",             DataPropertyName = "Id",             HeaderText = "ID",          Width = 50,  FillWeight = 8  },
                new DataGridViewTextBoxColumn { Name = "SubmissionDate", DataPropertyName = "SubmissionDate", HeaderText = "Date",        Width = 130, FillWeight = 15 },
                new DataGridViewTextBoxColumn { Name = "Category",       DataPropertyName = "Category",       HeaderText = "Category",    Width = 100, FillWeight = 12 },
                new DataGridViewTextBoxColumn { Name = "Priority",       DataPropertyName = "Priority",       HeaderText = "Priority",    Width = 80,  FillWeight = 10 },
                new DataGridViewTextBoxColumn { Name = "Location",       DataPropertyName = "Location",       HeaderText = "Location",    Width = 150, FillWeight = 18 },
                new DataGridViewTextBoxColumn { Name = "Description",    DataPropertyName = "Description",    HeaderText = "Description", Width = 200, FillWeight = 25 },
                new DataGridViewTextBoxColumn { Name = "Status",         DataPropertyName = "Status",         HeaderText = "Status",      Width = 90,  FillWeight = 10 },
                new DataGridViewTextBoxColumn { Name = "ContactPhone",   DataPropertyName = "ContactPhone",   HeaderText = "Phone",       Width = 100, FillWeight = 10 },
                new DataGridViewTextBoxColumn { Name = "ContactEmail",   DataPropertyName = "ContactEmail",   HeaderText = "Email",       Width = 120, FillWeight = 12 },
                new DataGridViewTextBoxColumn { Name = "AttachmentPath", DataPropertyName = "AttachmentPath", HeaderText = "Attachment",  Width = 120, FillWeight = 12 },
            });
        }

        /// <summary>Populates the DataGridView with issue data from the repository.</summary>
        private void LoadData()
        {
            var issues = _repository.GetAllIssues();
            dgvIssues.DataSource = issues;

            if (issues.Count == 0)
            {
                MessageBox.Show("No issues have been reported yet.",
                    "Issue History", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnClose_Click(object? sender, EventArgs e)
        {
            this.Close();
        }
    }
}

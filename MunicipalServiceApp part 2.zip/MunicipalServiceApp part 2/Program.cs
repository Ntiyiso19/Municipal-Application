using MunicipalServiceApp.Data;

namespace MunicipalServiceApp
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the Municipal Service Portal application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // Single shared repository instance for the entire application lifetime
            var repository = new IssueRepository();

            Application.Run(new MainMenuForm(repository));
        }
    }
}
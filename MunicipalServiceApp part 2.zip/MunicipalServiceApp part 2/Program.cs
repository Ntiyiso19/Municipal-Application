﻿using MunicipalServiceApp.Data;

namespace MunicipalServiceApp
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the Municipal Service Portal application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // Shared repository and event manager instances for the entire application lifetime
            var repository = new IssueRepository();
            var eventManager = new EventManager();

            Application.Run(new MainMenuForm(repository, eventManager));
        }
    }
}

﻿using MunicipalServiceApp.Data;
using MunicipalServiceApp.Models;

namespace MunicipalServiceApp.Services
{
    /// <summary>
    /// Intelligent Recommendation Engine (30 Marks).
    /// 1. Analyses user search patterns and preferences (category frequencies, tag intersections, bookmarks).
    /// 2. Uses a PriorityQueue<RecommendationScore, double> (Max-Heap equivalent) to rank top events.
    /// 3. Computes content relevance and temporal proximity to provide personalized suggestions with transparent reasoning.
    /// </summary>
    public class RecommendationEngine
    {
        private readonly EventManager _eventManager;

        public RecommendationEngine(EventManager eventManager)
        {
            _eventManager = eventManager;
        }

        /// <summary>
        /// Generates ranked recommendations based on active user preferences.
        /// Utilises PriorityQueue data structure for top-K extraction.
        /// </summary>
        public List<RecommendationScore> GetRecommendations(int topCount = 6)
        {
            var allEvents = _eventManager.GetAllEvents();
            if (allEvents.Count == 0) return new List<RecommendationScore>();

            int totalSearches = _eventManager.TotalSearchesCount;
            var catCounts = _eventManager.CategorySearchCounts;
            var tagCounts = _eventManager.TagSearchCounts;
            var bookmarkedIds = _eventManager.BookmarkedEventIds;

            // Extract the user's top searched tags into a HashSet for rapid set operations (O(1))
            var userTopTags = new HashSet<string>(
                tagCounts.OrderByDescending(kv => kv.Value).Take(15).Select(kv => kv.Key),
                StringComparer.OrdinalIgnoreCase
            );

            // PriorityQueue where priority = -score (inverted so highest score dequeues first)
            var rankingQueue = new PriorityQueue<RecommendationScore, double>();

            DateTime today = DateTime.Today;

            foreach (var ev in allEvents)
            {
                // Only consider future or ongoing events
                if (ev.EventDate.Date < today.AddDays(-1)) continue;

                double score = 0.0;
                var matchedTags = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                bool catMatched = false;
                var reasonParts = new List<string>();

                // --- Factor 1: Category Preference Match (Up to 40 Marks/Points) ---
                if (totalSearches > 0 && catCounts.TryGetValue(ev.Category, out int catCount) && catCount > 0)
                {
                    catMatched = true;
                    double catRatio = (double)catCount / totalSearches;
                    double catScore = Math.Min(40.0, catRatio * 45.0 + 15.0);
                    score += catScore;
                    reasonParts.Add($"Matches your frequent category '{ev.Category}' ({catCount} search{(catCount > 1 ? "es" : "")})");
                }
                else if (totalSearches == 0)
                {
                    // Cold-start heuristic: municipal priority and essential events
                    if (ev.Priority >= EventPriority.High)
                    {
                        score += 25.0;
                        reasonParts.Add("High municipal priority alert");
                    }
                    else
                    {
                        score += 15.0;
                    }
                }

                // --- Factor 2: Tag / Keyword Overlap using Set Intersect (Up to 35 Points) ---
                if (userTopTags.Count > 0 && ev.Tags.Count > 0)
                {
                    // Set intersection
                    var intersection = new HashSet<string>(ev.Tags, StringComparer.OrdinalIgnoreCase);
                    intersection.IntersectWith(userTopTags);

                    if (intersection.Count > 0)
                    {
                        matchedTags = intersection;
                        double tagScore = Math.Min(35.0, intersection.Count * 12.0);
                        score += tagScore;
                        reasonParts.Add($"Tags match your interests: [{string.Join(", ", intersection)}]");
                    }
                }

                // --- Factor 3: Temporal Proximity / Immediacy (Up to 15 Points) ---
                int daysUntil = ev.DaysUntil;
                if (daysUntil is >= 0 and <= 3)
                {
                    score += 15.0;
                    reasonParts.Add(daysUntil == 0 ? "Happening today!" : $"Happening in {daysUntil} day{(daysUntil > 1 ? "s" : "")}");
                }
                else if (daysUntil is > 3 and <= 7)
                {
                    score += 10.0;
                    reasonParts.Add($"Upcoming this week ({daysUntil} days away)");
                }
                else if (daysUntil is > 7 and <= 14)
                {
                    score += 5.0;
                }

                // --- Factor 4: Municipal Urgency / Priority (Up to 10 Points) ---
                score += ev.Priority switch
                {
                    EventPriority.Critical => 10.0,
                    EventPriority.High => 7.0,
                    EventPriority.Medium => 4.0,
                    _ => 1.0
                };

                // --- Factor 5: Bookmark Affinity Boost (Up to 10 Points) ---
                if (bookmarkedIds.Contains(ev.Id))
                {
                    score += 10.0;
                    reasonParts.Add("Bookmarked in your saved list");
                }

                // Cap maximum score at 99.5%
                score = Math.Min(99.0, Math.Max(10.0, score));

                string explanation = reasonParts.Count > 0
                    ? string.Join(" • ", reasonParts)
                    : $"Recommended based on category '{ev.Category}' and upcoming schedule";

                var rec = new RecommendationScore
                {
                    Event = ev,
                    Score = score,
                    MatchReason = explanation,
                    CategoryMatched = catMatched,
                    MatchedTags = matchedTags
                };

                // Enqueue with negative score for Max-Priority behaviour
                rankingQueue.Enqueue(rec, -score);
            }

            // Extract Top N recommendations from Priority Queue
            var results = new List<RecommendationScore>();
            while (rankingQueue.Count > 0 && results.Count < topCount)
            {
                results.Add(rankingQueue.Dequeue());
            }

            return results;
        }

        /// <summary>
        /// Summarises active search preference statistics for transparent analytics display.
        /// </summary>
        public string GetPreferenceProfileSummary()
        {
            int total = _eventManager.TotalSearchesCount;
            if (total == 0)
            {
                return "No searches recorded yet. Search or browse categories to tailor your recommendations!";
            }

            var topCat = _eventManager.CategorySearchCounts
                .OrderByDescending(kv => kv.Value)
                .FirstOrDefault();

            var topTags = _eventManager.TagSearchCounts
                .OrderByDescending(kv => kv.Value)
                .Take(5)
                .Select(kv => kv.Key);

            string topTagsStr = topTags.Any() ? string.Join(", ", topTags) : "None yet";
            return $"Active Profile: {total} searches • Top Category: '{topCat.Key}' ({topCat.Value}x) • Key Interests: [{topTagsStr}]";
        }
    }
}

﻿using MunicipalServiceApp.Models;

namespace MunicipalServiceApp
{
    /// <summary>
    /// Shared colour palette and style constants used across all forms
    /// to maintain a consistent, modern look and feel.
    /// </summary>
    internal static class AppTheme
    {
        // ─── Colours ──────────────────────────────────────────────────────────
        public static readonly Color PrimaryBlue     = Color.FromArgb(30, 60, 114);
        public static readonly Color AccentBlue      = Color.FromArgb(42, 82, 152);
        public static readonly Color LightBlue       = Color.FromArgb(220, 232, 250);
        public static readonly Color SoftGray        = Color.FromArgb(240, 243, 246);
        public static readonly Color DarkText        = Color.FromArgb(33, 37, 41);
        public static readonly Color MutedText       = Color.FromArgb(108, 117, 125);
        public static readonly Color WhiteBg         = Color.FromArgb(248, 249, 250);
        public static readonly Color CardBg          = Color.White;
        public static readonly Color SuccessGreen    = Color.FromArgb(40, 167, 69);
        public static readonly Color WarningOrange   = Color.FromArgb(255, 153, 0);
        public static readonly Color DangerRed       = Color.FromArgb(220, 53, 69);
        public static readonly Color PurpleAccent    = Color.FromArgb(111, 66, 193);
        public static readonly Color DisabledGray    = Color.FromArgb(180, 185, 190);
        public static readonly Color BorderColor     = Color.FromArgb(206, 212, 218);
        public static readonly Color ProgressBarColor = Color.FromArgb(0, 123, 255);

        // ─── Fonts ────────────────────────────────────────────────────────────
        public static readonly Font HeadingFont   = new("Segoe UI", 20F, FontStyle.Bold);
        public static readonly Font SubHeadingFont = new("Segoe UI", 13F, FontStyle.Regular);
        public static readonly Font LabelFont      = new("Segoe UI", 10F, FontStyle.Regular);
        public static readonly Font LabelBoldFont  = new("Segoe UI", 10F, FontStyle.Bold);
        public static readonly Font ButtonFont     = new("Segoe UI", 10.5F, FontStyle.Bold);
        public static readonly Font SmallFont      = new("Segoe UI", 9F, FontStyle.Regular);
        public static readonly Font SmallBoldFont  = new("Segoe UI", 9F, FontStyle.Bold);
        public static readonly Font LargeStatFont  = new("Segoe UI", 18F, FontStyle.Bold);

        // ─── Helpers ──────────────────────────────────────────────────────────

        /// <summary>Applies the standard look to a primary action button.</summary>
        public static void StylePrimaryButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = PrimaryBlue;
            btn.ForeColor = Color.White;
            btn.Font = ButtonFont;
            btn.Cursor = Cursors.Hand;
            btn.Height = 40;

            btn.MouseEnter += (s, e) => btn.BackColor = AccentBlue;
            btn.MouseLeave += (s, e) => btn.BackColor = PrimaryBlue;
        }

        /// <summary>Applies the standard look to a secondary (outline) button.</summary>
        public static void StyleSecondaryButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderColor = PrimaryBlue;
            btn.FlatAppearance.BorderSize = 1;
            btn.BackColor = Color.White;
            btn.ForeColor = PrimaryBlue;
            btn.Font = ButtonFont;
            btn.Cursor = Cursors.Hand;
            btn.Height = 40;

            btn.MouseEnter += (s, e) => { btn.BackColor = PrimaryBlue; btn.ForeColor = Color.White; };
            btn.MouseLeave += (s, e) => { btn.BackColor = Color.White; btn.ForeColor = PrimaryBlue; };
        }

        /// <summary>Applies the standard look to a success (green) button.</summary>
        public static void StyleSuccessButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = SuccessGreen;
            btn.ForeColor = Color.White;
            btn.Font = ButtonFont;
            btn.Cursor = Cursors.Hand;
            btn.Height = 40;

            btn.MouseEnter += (s, e) => btn.BackColor = Color.FromArgb(34, 142, 58);
            btn.MouseLeave += (s, e) => btn.BackColor = SuccessGreen;
        }

        /// <summary>Applies the standard look to a disabled button.</summary>
        public static void StyleDisabledButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = DisabledGray;
            btn.ForeColor = Color.White;
            btn.Font = ButtonFont;
            btn.Enabled = false;
            btn.Cursor = Cursors.No;
            btn.Height = 40;
        }

        /// <summary>Applies the standard look to a danger (red) button.</summary>
        public static void StyleDangerButton(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = DangerRed;
            btn.ForeColor = Color.White;
            btn.Font = ButtonFont;
            btn.Cursor = Cursors.Hand;
            btn.Height = 40;

            btn.MouseEnter += (s, e) => btn.BackColor = Color.FromArgb(200, 35, 51);
            btn.MouseLeave += (s, e) => btn.BackColor = DangerRed;
        }

        /// <summary>Retrieves theme colour for event priority levels.</summary>
        public static Color GetPriorityColor(EventPriority priority) => priority switch
        {
            EventPriority.Critical => DangerRed,
            EventPriority.High => WarningOrange,
            EventPriority.Medium => AccentBlue,
            _ => MutedText
        };
    }
}

using MunicipalServiceApp.Data;
using MunicipalServiceApp.Models;

namespace MunicipalServiceApp
{
    /// <summary>
    /// Report Issues form – allows citizens to fill in issue details,
    /// attach media, and submit the report. Includes validation,
    /// engagement feedback, CSV export, and navigation to the issues
    /// history view.
    /// </summary>
    public partial class ReportIssuesForm : Form
    {
        private readonly IssueRepository _repository;
        private string _attachmentPath = string.Empty;

        // Maximum attachment size: 5 MB
        private const long MaxAttachmentBytes = 5 * 1024 * 1024;

        // Engagement messages shown as the user fills in the form
        private static readonly string[] EngagementMessages = new[]
        {
            "Let's get started – enter the location!",
            "Great! Now pick a category.",
            "Almost there – describe the issue.",
            "Looking good! You can attach a photo if you like.",
            "Ready to submit – thank you for making our community better! 🎉"
        };

        // ── Constructor ────────────────────────────────────────────────

        public ReportIssuesForm(IssueRepository repository)
        {
            _repository = repository;
            InitializeComponent();
            UpdateStats();
            UpdateProgress();
        }

        // ── Validation ─────────────────────────────────────────────────

        /// <summary>Validates required fields and returns true if the form is ready to submit.</summary>
        private bool ValidateForm()
        {
            if (string.IsNullOrWhiteSpace(txtLocation.Text))
            {
                MessageBox.Show("Please enter the location of the issue.",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLocation.Focus();
                return false;
            }

            if (cmbCategory.SelectedIndex < 0)
            {
                MessageBox.Show("Please select a category for the issue.",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbCategory.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(rtbDescription.Text))
            {
                MessageBox.Show("Please provide a description of the issue.",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                rtbDescription.Focus();
                return false;
            }

            if (rtbDescription.Text.Length > 1000)
            {
                MessageBox.Show("Description must not exceed 1 000 characters.",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                rtbDescription.Focus();
                return false;
            }

            return true;
        }

        // ── Progress & engagement ──────────────────────────────────────

        /// <summary>
        /// Calculates how many of the required fields have been filled in
        /// and updates the ProgressBar and engagement label accordingly.
        /// </summary>
        private void UpdateProgress()
        {
            int filled = 0;
            if (!string.IsNullOrWhiteSpace(txtLocation.Text)) filled++;
            if (cmbCategory.SelectedIndex >= 0) filled++;
            if (cmbPriority.SelectedIndex >= 0) filled++;
            if (!string.IsNullOrWhiteSpace(rtbDescription.Text)) filled++;

            // Progress: 0 – 100 (four required fields)
            int pct = (int)(filled / 4.0 * 100);
            progressBar.Value = Math.Min(pct, 100);

            int msgIndex = Math.Min(filled, EngagementMessages.Length - 1);
            lblEngagement.Text = EngagementMessages[msgIndex];

            // Colour hint
            lblEngagement.ForeColor = filled >= 4
                ? AppTheme.SuccessGreen
                : AppTheme.AccentBlue;
        }

        /// <summary>Refreshes the stats label in the header.</summary>
        private void UpdateStats()
        {
            lblStats.Text = $"Today: {_repository.TodaysReports}  |  Total: {_repository.TotalReports}";
        }

        // ── Event handlers ─────────────────────────────────────────────

        private void RtbDescription_TextChanged(object? sender, EventArgs e)
        {
            int len = rtbDescription.Text.Length;
            lblCharCount.Text = $"{len} / 1000 characters";
            lblCharCount.ForeColor = len > 1000 ? AppTheme.DangerRed : AppTheme.MutedText;
            UpdateProgress();
        }

        private void BtnAttach_Click(object? sender, EventArgs e)
        {
            using var dlg = new OpenFileDialog
            {
                Title = "Select an image or document",
                Filter = "Images|*.jpg;*.jpeg;*.png;*.bmp;*.gif|Documents|*.pdf;*.docx;*.doc;*.txt|All files|*.*"
            };

            if (dlg.ShowDialog() != DialogResult.OK) return;

            var fileInfo = new FileInfo(dlg.FileName);
            if (fileInfo.Length > MaxAttachmentBytes)
            {
                MessageBox.Show(
                    $"The selected file is {fileInfo.Length / 1024.0 / 1024.0:F1} MB.\nMaximum allowed size is 5 MB.",
                    "File Too Large", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _attachmentPath = dlg.FileName;
            lblAttachmentInfo.Text = $"✔ {fileInfo.Name} ({fileInfo.Length / 1024.0:F0} KB)";
            lblAttachmentInfo.ForeColor = AppTheme.SuccessGreen;
        }

        private void BtnSubmit_Click(object? sender, EventArgs e)
        {
            if (!ValidateForm()) return;

            var issue = new IssueReport
            {
                Location = txtLocation.Text.Trim(),
                Category = cmbCategory.SelectedItem!.ToString()!,
                Priority = cmbPriority.SelectedItem?.ToString() ?? "Medium",
                Description = rtbDescription.Text.Trim(),
                AttachmentPath = _attachmentPath,
                ContactPhone = txtContactPhone.Text.Trim(),
                ContactEmail = txtContactEmail.Text.Trim()
            };

            _repository.AddIssue(issue);
            UpdateStats();

            MessageBox.Show(
                $"Issue #{issue.Id} submitted successfully!\n\n" +
                $"Category: {issue.Category}\n" +
                $"Location: {issue.Location}\n\n" +
                "Thank you for helping improve our community!",
                "Report Submitted",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            ClearForm();
        }

        private void BtnClear_Click(object? sender, EventArgs e)
        {
            var result = MessageBox.Show(
                "Are you sure you want to clear all fields?",
                "Confirm Clear", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
                ClearForm();
        }

        private void BtnExportCsv_Click(object? sender, EventArgs e)
        {
            if (_repository.TotalReports == 0)
            {
                MessageBox.Show("There are no issues to export.",
                    "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using var dlg = new SaveFileDialog
            {
                Title = "Export Issues to CSV",
                Filter = "CSV files|*.csv",
                FileName = $"issues_export_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };

            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                _repository.ExportToCsv(dlg.FileName);
                MessageBox.Show($"Exported {_repository.TotalReports} issue(s) to:\n{dlg.FileName}",
                    "Export Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed:\n{ex.Message}",
                    "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnViewIssues_Click(object? sender, EventArgs e)
        {
            var historyForm = new IssuesHistoryForm(_repository);
            historyForm.ShowDialog();
        }

        private void BtnBack_Click(object? sender, EventArgs e)
        {
            this.Close();
        }

        // ── Helpers ────────────────────────────────────────────────────

        /// <summary>Resets the form to its default empty state.</summary>
        private void ClearForm()
        {
            txtLocation.Clear();
            cmbCategory.SelectedIndex = -1;
            cmbPriority.SelectedIndex = 1; // Medium
            rtbDescription.Clear();
            txtContactPhone.Clear();
            txtContactEmail.Clear();
            _attachmentPath = string.Empty;
            lblAttachmentInfo.Text = "No file selected";
            lblAttachmentInfo.ForeColor = AppTheme.MutedText;
            UpdateProgress();
        }

        // Hook up additional change events after the form is shown
        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            txtLocation.TextChanged += (s, ev) => UpdateProgress();
            cmbCategory.SelectedIndexChanged += (s, ev) => UpdateProgress();
            cmbPriority.SelectedIndexChanged += (s, ev) => UpdateProgress();
        }
    }
}

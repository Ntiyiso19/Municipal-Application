# Municipal Service Portal – README

A **C# .NET 8 Windows Forms** application that enables citizens to report municipal issues (potholes, sanitation problems, broken street lights, etc.) to their local municipality. Built for **Visual Studio 2022**.

---

## Table of Contents

1. [Features](#features)
2. [Prerequisites](#prerequisites)
3. [How to Compile](#how-to-compile)
4. [How to Run](#how-to-run)
5. [How to Use](#how-to-use)
6. [Project Structure](#project-structure)
7. [Data Storage](#data-storage)
8. [Technical Notes](#technical-notes)

---

## Features

| Feature | Description |
|---|---|
| **Main Menu** | Three service options – *Report Issues* (active), *Local Events* and *Service Status* (disabled / coming soon), plus an *Exit* button. |
| **Report Issues** | Full reporting form with location, category, priority, rich-text description, optional contact info, and media attachment. |
| **Media Attachment** | Attach images (JPG, PNG, BMP, GIF) or documents (PDF, DOCX, TXT) up to **5 MB**. Image files display an inline preview. |
| **Validation** | Required-field validation with clear error messages. Character counter on the description field (max 1 000 chars). |
| **Engagement** | A progress bar and dynamic messages encourage the user as they fill in each field. |
| **Issue History** | View all submitted issues in a sortable DataGridView. |
| **CSV Export** | Export all issues to a CSV file for external reporting or analysis. |
| **JSON Persistence** | Issues are saved to a local JSON file (`issues.json`) in `%LOCALAPPDATA%\MunicipalServiceApp` so data persists between sessions. |
| **Statistics** | The Report Issues header shows today's and all-time issue counts. |

---

## Prerequisites

- **Visual Studio 2022** (v17.8 or later recommended)
- **.NET 8 SDK** (installed with Visual Studio or from [https://dotnet.microsoft.com](https://dotnet.microsoft.com))
- **Windows 10/11**

---

## How to Compile

### Option A – Visual Studio 2022

1. Open `MunicipalServiceApp.sln` (or open the folder containing the `.csproj`).
2. Ensure the target framework is set to `net8.0-windows` (already configured in the `.csproj`).
3. **Build → Build Solution** (`Ctrl + Shift + B`).

### Option B – .NET CLI

```bash
cd MunicipalServiceApp
dotnet restore
dotnet build
```

---

## How to Run

### Option A – Visual Studio

Press **F5** (Debug) or **Ctrl + F5** (Run without debugging).

### Option B – .NET CLI

```bash
dotnet run --project MunicipalServiceApp.csproj
```

The **Main Menu** window will appear on startup.

---

## How to Use

### 1. Main Menu

The application starts with three buttons:

- **Report Issues** – Opens the reporting form *(active)*.
- **Local Events & Announcements** – Disabled; planned for a future release.
- **Service Request Status** – Disabled; planned for a future release.
- **Exit** – Closes the application (with confirmation).

### 2. Report Issues Form

| Control | Description |
|---|---|
| **Location** (required) | Enter the address or area where the issue was observed. |
| **Category** (required) | Select from: Sanitation, Roads, Utilities, Water & Sewer, Parks & Recreation, Public Safety, Noise Complaint, Illegal Dumping, Street Lighting, Other. |
| **Priority** (required) | Select: Low, Medium (default), High, or Critical. |
| **Description** (required) | Describe the issue in detail (up to 1 000 characters). A live character counter is shown. |
| **Contact Phone** (optional) | Provide a phone number if you'd like to be contacted. |
| **Contact Email** (optional) | Provide an email address if you'd like to be contacted. |
| **Attach File** | Click **Browse…** to attach an image or document (max 5 MB). Image files show an inline preview. |
| **Submit Report** | Validates and saves the issue. A success message is displayed. |
| **Clear Form** | Resets all fields to their default state (with confirmation). |
| **Export CSV** | Exports all stored issues to a `.csv` file. |
| **View Issues** | Opens the **Issue History** window. |
| **Back to Main Menu** | Returns to the main menu. |

### 3. Issue History

A DataGridView showing all submitted issues with columns: ID, Date, Category, Priority, Location, Description, Status, Phone, Email, Attachment.

---

## Project Structure

```
MunicipalServiceApp/
├── Data/
│   └── IssueRepository.cs        # In-memory list + JSON persistence + CSV export
├── Models/
│   └── IssueReport.cs            # Data model (10 fields)
├── AppTheme.cs                   # Shared colours, fonts, and button-styling helpers
├── MainMenuForm.cs               # Main menu code-behind
├── MainMenuForm.Designer.cs      # Main menu UI layout
├── ReportIssuesForm.cs           # Report Issues code-behind
├── ReportIssuesForm.Designer.cs  # Report Issues UI layout
├── IssuesHistoryForm.cs          # Issue History code-behind
├── IssuesHistoryForm.Designer.cs # Issue History UI layout
├── Program.cs                    # Application entry point
├── MunicipalServiceApp.csproj    # Project file (.NET 8)
└── README.md                     # This file
```

---

## Data Storage

Issues are persisted as a JSON array in:

```
%LOCALAPPDATA%\MunicipalServiceApp\issues.json
```

The file is created automatically on first submission. Data survives application restarts.

---

## Technical Notes

- **Data Structures**: Issues are stored in a `List<IssueReport>` (in-memory) and serialised to JSON via `System.Text.Json`.
- **File Validation**: Attachments are validated against a 5 MB limit before acceptance.
- **Engagement Strategy**: A `ProgressBar` + dynamic `Label` provide real-time feedback as the user completes each required field, encouraging completion.
- **Responsive Layout**: The Report Issues form uses `AutoScroll` and anchored controls to handle varying window sizes.
- **Consistent Theming**: All forms share colours, fonts, and button styles defined in `AppTheme.cs`.

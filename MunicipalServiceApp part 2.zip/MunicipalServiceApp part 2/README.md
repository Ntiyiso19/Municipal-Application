﻿# Municipal Service Portal — README

A **C# .NET 8 Windows Forms** application designed for local government service delivery, citizen reporting, and community engagement. Built for **Visual Studio 2022**.

---

## Table of Contents

1. [System Overview](#system-overview)
2. [Features & Modules](#features--modules)
3. [Part 2: Local Events and Announcements (70 Marks)](#part-2-local-events-and-announcements-70-marks)
   - [Technical Requirements & Data Structures (40 Marks)](#technical-requirements--data-structures-40-marks)
   - [Intelligent Recommendation Engine (30 Marks)](#intelligent-recommendation-engine-30-marks)
4. [Prerequisites](#prerequisites)
5. [How to Compile & Run](#how-to-compile--run)
6. [Project Structure](#project-structure)
7. [Data Storage & Persistence](#data-storage--persistence)

---

## System Overview

The Municipal Service Portal serves as a unified digital interface between citizens and local government administration. It provides seamless issue reporting and a comprehensive, data-structure-optimized **Local Events & Public Announcements** system.

---

## Features & Modules

| Feature | Status | Description |
|---|---|---|
| **Main Menu** | Active | Portal landing hub with direct navigation to all active modules. |
| **Report Issues** | Active (Part 1) | Interactive issue reporting form with file attachments, progress engagement bar, live validation, and CSV export. |
| **Local Events & Announcements** | **Active (Part 2 - 70 Marks)** | High-performance events explorer, search engine, urgent announcement queues, and personalized recommendation engine. |
| **Service Status** | Placeholder | Planned for future release. |
---

## Part 2: Local Events and Announcements (70 Marks)

### Technical Requirements & Data Structures (40 Marks)

#### 1. Stacks, Queues, and Priority Queues (15 Marks)
- **`Stack<SearchQuery>` (`_searchHistoryStack`)**:
  - Implements a LIFO stack tracking user search actions.
  - Powers the **Undo Search (↺)** button and the **Search History Stack** inspection tab, allowing citizens to step back through prior search filter states.
- **`Stack<int>` (`_viewHistoryStack`)**:
  - Maintains recently viewed event IDs, supporting drill-down navigation and user behavior auditing.
- **`Queue<EventItem>` (`_announcementQueue`)**:
  - Implements a FIFO queue for live municipal announcements.
  - Powers the top marquee banner with cyclical rotation (`RotateAnnouncementQueue`) and dequeue capabilities (`DequeueNotice`).
- **`PriorityQueue<EventItem, int>` (`_urgentAlertsPriorityQueue`)**:
  - Min-Heap priority queue where urgency levels are mapped to numerical ranks (`Critical` = 1, `High` = 2, `Medium` = 3, `Low` = 4).
  - Ensures critical municipal notices (such as severe weather alerts and major water pipe bursts) are dequeued and presented first.

#### 2. Hash Tables, Dictionaries, and Sorted Dictionaries (15 Marks)
- **`SortedDictionary<DateTime, List<EventItem>>` (`_eventsByDate`)**:
  - Organises all events chronologically using a balanced Red-Black Tree.
  - Optimises date range scanning (`GetEventsByDateRange`) by traversing sorted keys and stopping early when keys exceed the upper boundary.
- **`Dictionary<string, List<EventItem>>` (`_eventsByCategory`)**:
  - Hash table providing `O(1)` average time complexity for category-specific event retrieval with case-insensitive matching (`StringComparer.OrdinalIgnoreCase`).
- **`Dictionary<int, EventItem>` (`_eventsById`)**:
  - Hash table mapping primary IDs to event objects for instant lookups.
- **`Dictionary<string, int>` (`_categorySearchCounts` & `_tagSearchCounts`)**:
  - Real-time frequency maps tracking citizen query patterns across categories and tags.

#### 3. Sets (10 Marks)
- **`HashSet<string>` (`_uniqueCategories`)**:
  - Ensures unique municipal category registers without duplication; populates UI filter controls in `O(N)`.
- **`HashSet<DateTime>` (`_uniqueEventDates`)**:
  - Set tracking all distinct calendar dates that have scheduled events, enabling `O(1)` date checks (`HasEventOnDate`).
- **`HashSet<string>` on `EventItem` (`Tags`)**:
  - Fast membership testing and mathematical set intersections (`IntersectWith`) for tag overlap calculation in recommendation scoring.
- **`HashSet<int>` (`_bookmarkedEventIds`)**:
  - Tracks user-bookmarked events in `O(1)` lookup time.
### Intelligent Recommendation Engine (30 Marks)

1. **User Search Pattern Analysis**:
   - Analyzes category search counts, keyword frequencies, and bookmark preferences dynamically.
   - Calculates real-time affinity metrics and preference shares.
2. **Multi-Factor Scoring Algorithm**:
   - **Category Affinity (Up to 40 Points)**: Ratio of searches in that category relative to total searches.
   - **Tag Overlap / Content Similarity (Up to 35 Points)**: Set intersection between user interest tags and event tags using `HashSet<string>.IntersectWith`.
   - **Temporal Proximity (Up to 15 Points)**: Events occurring within 0–3 days receive maximum immediacy boost; 4–7 days receive moderate boost.
   - **Municipal Urgency (Up to 10 Points)**: Critical and high-priority municipal alerts receive elevated baseline visibility.
   - **Bookmark Affinity (+10 Points)**: Saved events receive affinity reinforcement.
3. **Data Structure Used for Recommendation Ranking**:
   - **`PriorityQueue<RecommendationScore, double>`**:
     - Candidates are ranked via an inverted priority score (Max-Heap equivalent) to extract the Top-N recommendations in `O(N log K)` time.
4. **User-Friendly Presentation**:
   - Dedicated "Personalized Recommendations" tab featuring match percentage badges (e.g. `⭐ 95% Match`), transparent "Why recommended" explanation text, and interactive view buttons.
   - Side-by-side search pattern analytics table showing category search frequencies and percentage shares.

---

## How to Compile & Run

### Option A — Visual Studio 2022
1. Open the solution or folder in Visual Studio.
2. Set build configuration to `Debug` / `Any CPU`.
3. Press **F5** to run.

### Option B — .NET CLI
```bash
dotnet restore
dotnet build
dotnet run
```

---

## Data Storage & Persistence
- Submitted issues: `%LOCALAPPDATA%\MunicipalServiceApp\issues.json`
- Municipal events & announcements: `%LOCALAPPDATA%\MunicipalServiceApp\events.json` (Pre-seeded with 16 realistic municipal events and notices on first launch).

namespace MunicipalServiceApp
{
    partial class ReportIssuesForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            // ── Control declarations ───────────────────────────────────
            pnlHeader = new Panel();
            lblHeader = new Label();
            lblStats = new Label();

            pnlBody = new Panel();

            lblLocation = new Label();
            txtLocation = new TextBox();

            lblCategory = new Label();
            cmbCategory = new ComboBox();

            lblPriority = new Label();
            cmbPriority = new ComboBox();

            lblDescription = new Label();
            rtbDescription = new RichTextBox();
            lblCharCount = new Label();

            lblContactPhone = new Label();
            txtContactPhone = new TextBox();

            lblContactEmail = new Label();
            txtContactEmail = new TextBox();

            lblAttachment = new Label();
            btnAttach = new Button();
            lblAttachmentInfo = new Label();

            progressBar = new ProgressBar();
            lblEngagement = new Label();

            btnSubmit = new Button();
            btnClear = new Button();
            btnExportCsv = new Button();
            btnViewIssues = new Button();
            btnBack = new Button();

            pnlHeader.SuspendLayout();
            pnlBody.SuspendLayout();
            SuspendLayout();

            // ── pnlHeader ──────────────────────────────────────────────
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Height = 80;
            pnlHeader.BackColor = AppTheme.PrimaryBlue;
            pnlHeader.Padding = new Padding(20, 0, 20, 0);
            pnlHeader.Controls.Add(lblStats);
            pnlHeader.Controls.Add(lblHeader);

            lblHeader.Dock = DockStyle.Left;
            lblHeader.Text = "📋  Report an Issue";
            lblHeader.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblHeader.ForeColor = Color.White;
            lblHeader.AutoSize = false;
            lblHeader.Width = 400;
            lblHeader.TextAlign = ContentAlignment.MiddleLeft;

            lblStats.Dock = DockStyle.Right;
            lblStats.Font = AppTheme.SmallFont;
            lblStats.ForeColor = AppTheme.LightBlue;
            lblStats.TextAlign = ContentAlignment.MiddleRight;
            lblStats.Width = 250;
            lblStats.Text = "Today: 0  |  Total: 0";

            // ── pnlBody (scrollable) ───────────────────────────────────
            pnlBody.Dock = DockStyle.Fill;
            pnlBody.AutoScroll = true;
            pnlBody.BackColor = AppTheme.WhiteBg;
            pnlBody.Padding = new Padding(30, 20, 30, 20);

            int y = 10;
            int labelW = 700;
            int fieldX = 30;

            // ── Location ───────────────────────────────────────────────
            lblLocation.Text = "Location *";
            lblLocation.Font = AppTheme.LabelBoldFont;
            lblLocation.ForeColor = AppTheme.DarkText;
            lblLocation.Location = new Point(fieldX, y);
            lblLocation.AutoSize = true;
            y += 24;

            txtLocation.Location = new Point(fieldX, y);
            txtLocation.Size = new Size(500, 30);
            txtLocation.Font = AppTheme.LabelFont;
            txtLocation.PlaceholderText = "e.g. 123 Main Street, Ward 5";
            txtLocation.BorderStyle = BorderStyle.FixedSingle;
            y += 40;

            // ── Category ───────────────────────────────────────────────
            lblCategory.Text = "Category *";
            lblCategory.Font = AppTheme.LabelBoldFont;
            lblCategory.ForeColor = AppTheme.DarkText;
            lblCategory.Location = new Point(fieldX, y);
            lblCategory.AutoSize = true;
            y += 24;

            cmbCategory.Location = new Point(fieldX, y);
            cmbCategory.Size = new Size(330, 30);
            cmbCategory.Font = AppTheme.LabelFont;
            cmbCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCategory.Items.AddRange(new object[]
            {
                "Sanitation", "Roads", "Utilities", "Water & Sewer",
                "Parks & Recreation", "Public Safety", "Noise Complaint",
                "Illegal Dumping", "Street Lighting", "Other"
            });
            y += 40;

            // ── Priority ──────────────────────────────────────────────
            lblPriority.Text = "Priority *";
            lblPriority.Font = AppTheme.LabelBoldFont;
            lblPriority.ForeColor = AppTheme.DarkText;
            lblPriority.Location = new Point(fieldX, y);
            lblPriority.AutoSize = true;
            y += 24;

            cmbPriority.Location = new Point(fieldX, y);
            cmbPriority.Size = new Size(330, 30);
            cmbPriority.Font = AppTheme.LabelFont;
            cmbPriority.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPriority.Items.AddRange(new object[] { "Low", "Medium", "High", "Critical" });
            cmbPriority.SelectedIndex = 1; // Default: Medium
            y += 40;

            // ── Description ────────────────────────────────────────────
            lblDescription.Text = "Description *";
            lblDescription.Font = AppTheme.LabelBoldFont;
            lblDescription.ForeColor = AppTheme.DarkText;
            lblDescription.Location = new Point(fieldX, y);
            lblDescription.AutoSize = true;
            y += 24;

            rtbDescription.Location = new Point(fieldX, y);
            rtbDescription.Size = new Size(500, 100);
            rtbDescription.Font = AppTheme.LabelFont;
            rtbDescription.BorderStyle = BorderStyle.FixedSingle;
            rtbDescription.TextChanged += RtbDescription_TextChanged;
            y += 104;

            lblCharCount.Text = "0 / 1000 characters";
            lblCharCount.Font = AppTheme.SmallFont;
            lblCharCount.ForeColor = AppTheme.MutedText;
            lblCharCount.Location = new Point(fieldX, y);
            lblCharCount.AutoSize = true;
            y += 26;

            // ── Contact Phone ──────────────────────────────────────────
            lblContactPhone.Text = "Contact Phone (optional)";
            lblContactPhone.Font = AppTheme.LabelBoldFont;
            lblContactPhone.ForeColor = AppTheme.DarkText;
            lblContactPhone.Location = new Point(fieldX, y);
            lblContactPhone.AutoSize = true;
            y += 24;

            txtContactPhone.Location = new Point(fieldX, y);
            txtContactPhone.Size = new Size(330, 30);
            txtContactPhone.Font = AppTheme.LabelFont;
            txtContactPhone.PlaceholderText = "e.g. 012 345 6789";
            txtContactPhone.BorderStyle = BorderStyle.FixedSingle;
            y += 40;

            // ── Contact Email ──────────────────────────────────────────
            lblContactEmail.Text = "Contact Email (optional)";
            lblContactEmail.Font = AppTheme.LabelBoldFont;
            lblContactEmail.ForeColor = AppTheme.DarkText;
            lblContactEmail.Location = new Point(fieldX, y);
            lblContactEmail.AutoSize = true;
            y += 24;

            txtContactEmail.Location = new Point(fieldX, y);
            txtContactEmail.Size = new Size(330, 30);
            txtContactEmail.Font = AppTheme.LabelFont;
            txtContactEmail.PlaceholderText = "e.g. citizen@email.com";
            txtContactEmail.BorderStyle = BorderStyle.FixedSingle;
            y += 40;

            // ── Attachment ─────────────────────────────────────────────
            lblAttachment.Text = "Attach Image / Document (optional, max 5 MB)";
            lblAttachment.Font = AppTheme.LabelBoldFont;
            lblAttachment.ForeColor = AppTheme.DarkText;
            lblAttachment.Location = new Point(fieldX, y);
            lblAttachment.AutoSize = true;
            y += 24;

            btnAttach.Text = "📎  Browse…";
            btnAttach.Location = new Point(fieldX, y);
            btnAttach.Size = new Size(160, 38);
            AppTheme.StyleSecondaryButton(btnAttach);
            btnAttach.Height = 38;
            btnAttach.Click += BtnAttach_Click;

            lblAttachmentInfo.Text = "No file selected";
            lblAttachmentInfo.Font = AppTheme.SmallFont;
            lblAttachmentInfo.ForeColor = AppTheme.MutedText;
            lblAttachmentInfo.Location = new Point(170, y + 10);
            lblAttachmentInfo.AutoSize = true;
            y += 48;

            // ── Progress & Engagement ──────────────────────────────────
            progressBar.Location = new Point(fieldX, y);
            progressBar.Size = new Size(labelW, 22);
            progressBar.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            progressBar.Minimum = 0;
            progressBar.Maximum = 100;
            progressBar.Value = 0;
            progressBar.Style = ProgressBarStyle.Continuous;
            y += 28;

            lblEngagement.Text = "Fill in the fields above to report your issue!";
            lblEngagement.Font = new Font("Segoe UI", 10F, FontStyle.Italic);
            lblEngagement.ForeColor = AppTheme.AccentBlue;
            lblEngagement.Location = new Point(fieldX, y);
            lblEngagement.AutoSize = true;
            y += 36;

            // ── Buttons row (FlowLayoutPanel) ──────────────────────────
            var flpButtons = new FlowLayoutPanel
            {
                Location = new Point(fieldX, y),
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true
            };

            btnSubmit.Text = "✅  Submit Report";
            btnSubmit.Size = new Size(180, 44);
            btnSubmit.Margin = new Padding(0, 0, 10, 10);
            AppTheme.StylePrimaryButton(btnSubmit);
            btnSubmit.Click += BtnSubmit_Click;

            btnClear.Text = "🗑️  Clear Form";
            btnClear.Size = new Size(150, 44);
            btnClear.Margin = new Padding(0, 0, 10, 10);
            AppTheme.StyleSecondaryButton(btnClear);
            btnClear.Click += BtnClear_Click;

            btnExportCsv.Text = "📄  Export CSV";
            btnExportCsv.Size = new Size(155, 44);
            btnExportCsv.Margin = new Padding(0, 0, 10, 10);
            AppTheme.StyleSecondaryButton(btnExportCsv);
            btnExportCsv.Click += BtnExportCsv_Click;

            btnViewIssues.Text = "📑  View Issues";
            btnViewIssues.Size = new Size(165, 44);
            btnViewIssues.Margin = new Padding(0, 0, 10, 10);
            AppTheme.StyleSecondaryButton(btnViewIssues);
            btnViewIssues.Click += BtnViewIssues_Click;

            btnBack.Text = "⬅️  Back to Main Menu";
            btnBack.Size = new Size(220, 44);
            btnBack.Margin = new Padding(0, 0, 10, 10);
            AppTheme.StyleDangerButton(btnBack);
            btnBack.Click += BtnBack_Click;

            flpButtons.Controls.AddRange(new Control[] {
                btnSubmit, btnClear, btnExportCsv, btnViewIssues, btnBack
            });

            y += 130;

            // ── Add controls to body panel ─────────────────────────────
            pnlBody.Controls.AddRange(new Control[]
            {
                lblLocation, txtLocation,
                lblCategory, cmbCategory,
                lblPriority, cmbPriority,
                lblDescription, rtbDescription, lblCharCount,
                lblContactPhone, txtContactPhone,
                lblContactEmail, txtContactEmail,
                lblAttachment, btnAttach, lblAttachmentInfo,
                progressBar, lblEngagement,
                flpButtons
            });

            // ── ReportIssuesForm ───────────────────────────────────────
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 700);
            Controls.Add(pnlBody);
            Controls.Add(pnlHeader);
            MinimumSize = new Size(780, 600);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Report an Issue – Municipal Service Portal";

            pnlHeader.ResumeLayout(false);
            pnlBody.ResumeLayout(false);
            pnlBody.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        // ── Field declarations ─────────────────────────────────────────
        private Panel pnlHeader;
        private Label lblHeader;
        private Label lblStats;
        private Panel pnlBody;

        private Label lblLocation;
        private TextBox txtLocation;

        private Label lblCategory;
        private ComboBox cmbCategory;

        private Label lblPriority;
        private ComboBox cmbPriority;

        private Label lblDescription;
        private RichTextBox rtbDescription;
        private Label lblCharCount;

        private Label lblContactPhone;
        private TextBox txtContactPhone;

        private Label lblContactEmail;
        private TextBox txtContactEmail;

        private Label lblAttachment;
        private Button btnAttach;
        private Label lblAttachmentInfo;

        private ProgressBar progressBar;
        private Label lblEngagement;

        private Button btnSubmit;
        private Button btnClear;
        private Button btnExportCsv;
        private Button btnViewIssues;
        private Button btnBack;
    }
}

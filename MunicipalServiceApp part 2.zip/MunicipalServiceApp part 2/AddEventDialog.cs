﻿using MunicipalServiceApp.Data;
using MunicipalServiceApp.Models;

namespace MunicipalServiceApp
{
    /// <summary>
    /// Dialog for adding a new municipal event or announcement.
    /// Incorporates validation and inserts the item across all EventManager data structures.
    /// </summary>
    public class AddEventDialog : Form
    {
        private readonly EventManager _manager;
        public EventItem? CreatedEvent { get; private set; }

        private TextBox txtTitle = null!;
        private ComboBox cmbCategory = null!;
        private DateTimePicker dtpDate = null!;
        private TextBox txtTimeSlot = null!;
        private TextBox txtLocation = null!;
        private ComboBox cmbPriority = null!;
        private CheckBox chkAnnouncement = null!;
        private TextBox txtOrganizer = null!;
        private TextBox txtContact = null!;
        private TextBox txtTags = null!;
        private TextBox txtDescription = null!;

        public AddEventDialog(EventManager manager)
        {
            _manager = manager;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Add New Municipal Event or Announcement";
            this.Size = new Size(620, 680);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = AppTheme.WhiteBg;

            // Header
            var pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 65,
                BackColor = AppTheme.PrimaryBlue,
                Padding = new Padding(20, 10, 20, 10)
            };
            var lblHeader = new Label
            {
                Text = "➕  Publish Local Event or Announcement",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft
            };
            pnlHeader.Controls.Add(lblHeader);

            // Body Panel with AutoScroll
            var pnlBody = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(24, 15, 24, 15)
            };

            int y = 10;

            // Title
            AddLabel("Event / Announcement Title: *", ref y, pnlBody);
            txtTitle = new TextBox { Location = new Point(24, y), Size = new Size(540, 28), Font = AppTheme.LabelFont };
            pnlBody.Controls.Add(txtTitle);
            y += 38;

            // Category & Priority Row
            AddLabel("Category: *", ref y, pnlBody, 260);
            cmbCategory = new ComboBox
            {
                Location = new Point(24, y),
                Size = new Size(250, 28),
                Font = AppTheme.LabelFont,
                DropDownStyle = ComboBoxStyle.DropDown
            };
            foreach (var cat in _manager.UniqueCategories)
            {
                cmbCategory.Items.Add(cat);
            }
            if (cmbCategory.Items.Count > 0) cmbCategory.SelectedIndex = 0;
            pnlBody.Controls.Add(cmbCategory);

            var lblPriority = new Label
            {
                Text = "Priority Urgency: *",
                Font = AppTheme.LabelBoldFont,
                ForeColor = AppTheme.DarkText,
                Location = new Point(300, y - 22),
                Size = new Size(200, 20)
            };
            pnlBody.Controls.Add(lblPriority);

            cmbPriority = new ComboBox
            {
                Location = new Point(300, y),
                Size = new Size(264, 28),
                Font = AppTheme.LabelFont,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbPriority.Items.AddRange(Enum.GetNames(typeof(EventPriority)));
            cmbPriority.SelectedItem = EventPriority.Medium.ToString();
            pnlBody.Controls.Add(cmbPriority);
            y += 38;

            // Date & Time Row
            AddLabel("Event Date: *", ref y, pnlBody, 260);
            dtpDate = new DateTimePicker
            {
                Location = new Point(24, y),
                Size = new Size(250, 28),
                Font = AppTheme.LabelFont,
                Format = DateTimePickerFormat.Short,
                Value = DateTime.Today.AddDays(1)
            };
            pnlBody.Controls.Add(dtpDate);

            var lblTime = new Label
            {
                Text = "Time Slot (e.g. 09:00 - 13:00):",
                Font = AppTheme.LabelBoldFont,
                ForeColor = AppTheme.DarkText,
                Location = new Point(300, y - 22),
                Size = new Size(260, 20)
            };
            pnlBody.Controls.Add(lblTime);

            txtTimeSlot = new TextBox
            {
                Location = new Point(300, y),
                Size = new Size(264, 28),
                Font = AppTheme.LabelFont,
                Text = "09:00 - 13:00"
            };
            pnlBody.Controls.Add(txtTimeSlot);
            y += 38;

            // Location
            AddLabel("Venue / Location: *", ref y, pnlBody);
            txtLocation = new TextBox { Location = new Point(24, y), Size = new Size(540, 28), Font = AppTheme.LabelFont };
            pnlBody.Controls.Add(txtLocation);
            y += 38;

            // Organizer & Contact
            AddLabel("Organizer Name:", ref y, pnlBody, 260);
            txtOrganizer = new TextBox
            {
                Location = new Point(24, y),
                Size = new Size(250, 28),
                Font = AppTheme.LabelFont,
                Text = "Local Municipality"
            };
            pnlBody.Controls.Add(txtOrganizer);

            var lblContact = new Label
            {
                Text = "Contact Info (Email/Phone):",
                Font = AppTheme.LabelBoldFont,
                ForeColor = AppTheme.DarkText,
                Location = new Point(300, y - 22),
                Size = new Size(260, 20)
            };
            pnlBody.Controls.Add(lblContact);

            txtContact = new TextBox
            {
                Location = new Point(300, y),
                Size = new Size(264, 28),
                Font = AppTheme.LabelFont,
                Text = "events@municipality.gov.za"
            };
            pnlBody.Controls.Add(txtContact);
            y += 38;

            // Announcement Checkbox
            chkAnnouncement = new CheckBox
            {
                Text = "📢 Mark as Official Announcement / Public Bulletin Notice",
                Location = new Point(24, y),
                Size = new Size(540, 26),
                Font = AppTheme.LabelBoldFont,
                ForeColor = AppTheme.PrimaryBlue
            };
            pnlBody.Controls.Add(chkAnnouncement);
            y += 34;

            // Tags (Comma separated)
            AddLabel("Topic Tags (comma-separated, e.g. water, maintenance, youth):", ref y, pnlBody);
            txtTags = new TextBox
            {
                Location = new Point(24, y),
                Size = new Size(540, 28),
                Font = AppTheme.LabelFont,
                Text = "community, municipal"
            };
            pnlBody.Controls.Add(txtTags);
            y += 38;

            // Description
            AddLabel("Detailed Description: *", ref y, pnlBody);
            txtDescription = new TextBox
            {
                Location = new Point(24, y),
                Size = new Size(540, 75),
                Font = AppTheme.LabelFont,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical
            };
            pnlBody.Controls.Add(txtDescription);
            y += 85;

            // Footer / Actions
            var pnlFooter = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 65,
                BackColor = Color.White,
                Padding = new Padding(20, 12, 20, 12)
            };

            var btnSave = new Button
            {
                Text = "✔ Save & Publish Event",
                Size = new Size(200, 40),
                Dock = DockStyle.Right
            };
            AppTheme.StylePrimaryButton(btnSave);
            btnSave.Click += BtnSave_Click;

            var btnCancel = new Button
            {
                Text = "Cancel",
                Size = new Size(110, 40),
                Dock = DockStyle.Left
            };
            AppTheme.StyleSecondaryButton(btnCancel);
            btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; this.Close(); };

            pnlFooter.Controls.Add(btnCancel);
            pnlFooter.Controls.Add(btnSave);

            this.Controls.Add(pnlBody);
            this.Controls.Add(pnlHeader);
            this.Controls.Add(pnlFooter);
        }

        private void AddLabel(string text, ref int y, Panel parent, int width = 540)
        {
            var lbl = new Label
            {
                Text = text,
                Font = AppTheme.LabelBoldFont,
                ForeColor = AppTheme.DarkText,
                Location = new Point(24, y),
                Size = new Size(width, 20)
            };
            parent.Controls.Add(lbl);
            y += 22;
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Please enter the event title.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTitle.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(cmbCategory.Text))
            {
                MessageBox.Show("Please select or enter a category.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbCategory.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtLocation.Text))
            {
                MessageBox.Show("Please enter the venue or location.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLocation.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                MessageBox.Show("Please enter an event description.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDescription.Focus();
                return;
            }

            // Extract tags into HashSet<string>
            var tagsSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (!string.IsNullOrWhiteSpace(txtTags.Text))
            {
                var parts = txtTags.Text.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var p in parts)
                {
                    string cleaned = p.Trim();
                    if (!string.IsNullOrEmpty(cleaned))
                    {
                        tagsSet.Add(cleaned);
                    }
                }
            }

            Enum.TryParse<EventPriority>(cmbPriority.SelectedItem?.ToString(), out var priority);

            var newEvent = new EventItem
            {
                Title = txtTitle.Text.Trim(),
                Category = cmbCategory.Text.Trim(),
                EventDate = dtpDate.Value.Date,
                TimeSlot = string.IsNullOrWhiteSpace(txtTimeSlot.Text) ? "All Day" : txtTimeSlot.Text.Trim(),
                Location = txtLocation.Text.Trim(),
                Description = txtDescription.Text.Trim(),
                Priority = priority,
                IsAnnouncement = chkAnnouncement.Checked,
                Organizer = string.IsNullOrWhiteSpace(txtOrganizer.Text) ? "Local Municipality" : txtOrganizer.Text.Trim(),
                ContactInfo = string.IsNullOrWhiteSpace(txtContact.Text) ? "events@municipality.gov.za" : txtContact.Text.Trim(),
                Tags = tagsSet
            };

            _manager.AddEvent(newEvent, persist: true);
            CreatedEvent = newEvent;

            MessageBox.Show($"'{newEvent.Title}' was successfully published and added to municipal event registries!",
                "Event Published", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}

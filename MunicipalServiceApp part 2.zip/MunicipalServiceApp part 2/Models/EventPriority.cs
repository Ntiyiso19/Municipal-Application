﻿namespace MunicipalServiceApp.Models
{
    /// <summary>
    /// Priority level for local events and municipal announcements.
    /// Used for urgent queuing and recommendation scoring.
    /// </summary>
    public enum EventPriority
    {
        Low = 1,
        Medium = 2,
        High = 3,
        Critical = 4
    }
}

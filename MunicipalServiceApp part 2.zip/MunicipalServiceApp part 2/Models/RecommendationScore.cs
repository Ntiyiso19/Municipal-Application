﻿namespace MunicipalServiceApp.Models
{
    /// <summary>
    /// Models a recommended event with calculated relevance score and human-readable explanation.
    /// Utilised by the recommendation engine and PriorityQueue ranking.
    /// </summary>
    public class RecommendationScore
    {
        public EventItem Event { get; set; } = null!;
        public double Score { get; set; } // 0.0 - 100.0
        public string MatchReason { get; set; } = string.Empty;
        public bool CategoryMatched { get; set; }
        public HashSet<string> MatchedTags { get; set; } = new(StringComparer.OrdinalIgnoreCase);

        public string ScoreFormatted => $"{Math.Round(Score)}% Match";

        public override string ToString()
        {
            return $"{Event.Title} - {ScoreFormatted} ({MatchReason})";
        }
    }
}

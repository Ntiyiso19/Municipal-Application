using System.Text.Json.Serialization;

namespace MunicipalServiceApp.Models
{
    /// <summary>
    /// Represents a citizen-reported municipal issue.
    /// Contains all details captured during the report submission.
    /// </summary>
    public class IssueReport
    {
        /// <summary>Unique identifier for the issue report.</summary>
        public int Id { get; set; }

        /// <summary>Physical location / address of the reported issue.</summary>
        public string Location { get; set; } = string.Empty;

        /// <summary>Category of the issue (e.g., Sanitation, Roads, Utilities).</summary>
        public string Category { get; set; } = string.Empty;

        /// <summary>Priority level: Low, Medium, High, or Critical.</summary>
        public string Priority { get; set; } = "Medium";

        /// <summary>Detailed description of the issue provided by the citizen.</summary>
        public string Description { get; set; } = string.Empty;

        /// <summary>File path to any attached media (image or document).</summary>
        public string AttachmentPath { get; set; } = string.Empty;

        /// <summary>Optional contact phone number of the reporter.</summary>
        public string ContactPhone { get; set; } = string.Empty;

        /// <summary>Optional contact email of the reporter.</summary>
        public string ContactEmail { get; set; } = string.Empty;

        /// <summary>Current status of the report (Submitted, In Progress, Resolved).</summary>
        public string Status { get; set; } = "Submitted";

        /// <summary>Date and time the report was submitted.</summary>
        public DateTime SubmissionDate { get; set; } = DateTime.Now;

        /// <summary>Returns a short summary string for display.</summary>
        public override string ToString()
        {
            return $"[{Id}] {Category} – {Location} ({Status})";
        }
    }
}

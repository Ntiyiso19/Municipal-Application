﻿namespace MunicipalServiceApp.Models
{
    /// <summary>
    /// Represents a snapshot of a search query executed by the user.
    /// Pushed onto a Stack<SearchQuery> to maintain search history and enable undo.
    /// </summary>
    public class SearchQuery
    {
        public string Keyword { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public int ResultCount { get; set; }

        public string Summary
        {
            get
            {
                var parts = new List<string>();
                if (!string.IsNullOrWhiteSpace(Keyword)) parts.Add($"Keyword: '{Keyword}'");
                if (!string.IsNullOrWhiteSpace(Category) && Category != "All Categories") parts.Add($"Category: '{Category}'");
                if (StartDate.HasValue) parts.Add($"From: {StartDate.Value:yyyy-MM-dd}");
                if (EndDate.HasValue) parts.Add($"To: {EndDate.Value:yyyy-MM-dd}");

                string filterText = parts.Count > 0 ? string.Join(", ", parts) : "All Events";
                return $"[{Timestamp:HH:mm:ss}] {filterText} ({ResultCount} results)";
            }
        }

        public override string ToString() => Summary;
    }
}

﻿using System.Text.Json.Serialization;

namespace MunicipalServiceApp.Models
{
    /// <summary>
    /// Represents a municipal event or public announcement.
    /// Incorporates a HashSet of tags for efficient keyword and topic set operations.
    /// </summary>
    public class EventItem
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public DateTime EventDate { get; set; } = DateTime.Today;
        public string TimeSlot { get; set; } = "09:00 - 12:00";
        public string Location { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public EventPriority Priority { get; set; } = EventPriority.Medium;
        public bool IsAnnouncement { get; set; } = false;
        public string Organizer { get; set; } = "Local Municipality";
        public string ContactInfo { get; set; } = "support@municipality.gov.za";

        /// <summary>
        /// Set of unique tags associated with this event/announcement.
        /// Utilises HashSet for O(1) membership lookups and fast set intersection.
        /// </summary>
        public HashSet<string> Tags { get; set; } = new(StringComparer.OrdinalIgnoreCase);

        // Display properties for UI bindings and DataGridView
        [JsonIgnore]
        public string FormattedDate => EventDate.ToString("yyyy-MM-dd");

        [JsonIgnore]
        public string PriorityDisplay => Priority.ToString();

        [JsonIgnore]
        public string TypeDisplay => IsAnnouncement ? "📢 Announcement" : "📅 Event";

        [JsonIgnore]
        public string TagsDisplay => string.Join(", ", Tags);

        [JsonIgnore]
        public int DaysUntil => (EventDate.Date - DateTime.Today).Days;

        public override string ToString()
        {
            return $"[{TypeDisplay}] {Title} ({FormattedDate}) - {Category}";
        }
    }
}

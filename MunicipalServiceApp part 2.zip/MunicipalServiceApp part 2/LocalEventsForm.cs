﻿using MunicipalServiceApp.Data;
using MunicipalServiceApp.Models;
using MunicipalServiceApp.Services;

namespace MunicipalServiceApp
{
    /// <summary>
    /// Local Events and Announcements Form (70 Marks).
    /// Features:
    /// - Stacks, Queues, Priority Queues (15 Marks)
    /// - Hash Tables, Dictionaries, Sorted Dictionaries (15 Marks)
    /// - Sets for Unique Categories, Dates, and Tags (10 Marks)
    /// - Intelligent Recommendation Feature based on user searches (30 Marks)
    /// </summary>
    public partial class LocalEventsForm : Form
    {
        private readonly EventManager _eventManager;
        private readonly RecommendationEngine _recommendationEngine;

        // Active filter state
        private bool _isDateFilterActive = false;
        private EventItem? _currentTickerItem = null;

        public LocalEventsForm(EventManager eventManager)
        {
            _eventManager = eventManager;
            _recommendationEngine = new RecommendationEngine(_eventManager);

            InitializeComponent();
            ApplyCustomStyling();
            PopulateCategories();
            InitializeDateFilters();
            RefreshTicker();
            UpdateStats();
            ExecuteSearch(recordStack: false);
            LoadRecommendations();
            LoadPriorityNotices();
            RefreshSearchHistoryList();
        }

        // =========================================================================
        // UI POPULATION & EVENT DATA BINDING
        // =========================================================================

        private void PopulateCategories()
        {
            cmbCategory.Items.Clear();
            cmbCategory.Items.Add("All Categories");

            // Incorporates Sets: Retrieve unique categories from HashSet<string>
            foreach (var category in _eventManager.UniqueCategories.OrderBy(c => c))
            {
                cmbCategory.Items.Add(category);
            }

            cmbCategory.SelectedIndex = 0;
        }

        private void InitializeDateFilters()
        {
            dtpStartDate.Value = DateTime.Today;
            dtpEndDate.Value = DateTime.Today.AddDays(30);
            chkEnableDateFilter.Checked = false;
            dtpStartDate.Enabled = false;
            dtpEndDate.Enabled = false;
        }

        private void UpdateStats()
        {
            var all = _eventManager.GetAllEvents();
            int total = all.Count;
            int thisWeek = all.Count(e => e.DaysUntil >= 0 && e.DaysUntil <= 7);
            int alerts = all.Count(e => e.IsAnnouncement || e.Priority >= EventPriority.High);
            int searches = _eventManager.TotalSearchesCount;

            lblStatTotalVal.Text = total.ToString();
            lblStatWeekVal.Text = thisWeek.ToString();
            lblStatAlertsVal.Text = alerts.ToString();
            lblStatSearchesVal.Text = searches.ToString();
        }

        private void RefreshTicker()
        {
            // Announcement Queue (FIFO Queue)
            _currentTickerItem = _eventManager.RotateAnnouncementQueue();
            if (_currentTickerItem != null)
            {
                string prefix = _currentTickerItem.Priority == EventPriority.Critical ? "🚨 CRITICAL NOTICE" : "📢 NOTICE";
                lblTickerContent.Text = $"{prefix}: [{_currentTickerItem.Category}] {_currentTickerItem.Title} ({_currentTickerItem.FormattedDate}) — {_currentTickerItem.Location}";
                pnlTicker.BackColor = _currentTickerItem.Priority == EventPriority.Critical ? Color.FromArgb(253, 237, 237) : AppTheme.LightBlue;
                lblTickerContent.ForeColor = _currentTickerItem.Priority == EventPriority.Critical ? AppTheme.DangerRed : AppTheme.PrimaryBlue;
            }
            else
            {
                lblTickerContent.Text = "📢 No active announcements in queue.";
            }
        }

        // =========================================================================
        // SEARCH & FILTERING (SORTED DICTIONARY + HASH TABLE LOOKUPS)
        // =========================================================================

        private void ExecuteSearch(bool recordStack = true)
        {
            string keyword = txtSearch.Text.Trim();
            string category = cmbCategory.SelectedItem?.ToString() ?? "All Categories";
            DateTime? start = _isDateFilterActive ? dtpStartDate.Value.Date : null;
            DateTime? end = _isDateFilterActive ? dtpEndDate.Value.Date : null;

            // Search combines SortedDictionary<DateTime, List<EventItem>> and Dictionary<string, List<EventItem>>
            var results = _eventManager.SearchEvents(keyword, category, start, end);

            dgvEvents.DataSource = null;
            dgvEvents.DataSource = results;

            lblResultCount.Text = $"Showing {results.Count} events & notices (Organised via SortedDictionary & Hash Table)";

            // Update undo search button state (Stack<SearchQuery>)
            btnUndoSearch.Enabled = _eventManager.CanUndoSearch;
            btnUndoSearch.BackColor = _eventManager.CanUndoSearch ? AppTheme.PrimaryBlue : AppTheme.DisabledGray;

            // Update stats & recommendations dynamically
            UpdateStats();
            LoadRecommendations();
            RefreshSearchHistoryList();
        }

        private void BtnSearch_Click(object? sender, EventArgs e)
        {
            ExecuteSearch(recordStack: true);
        }

        private void BtnClearFilters_Click(object? sender, EventArgs e)
        {
            txtSearch.Text = string.Empty;
            cmbCategory.SelectedIndex = 0;
            chkEnableDateFilter.Checked = false;
            _isDateFilterActive = false;
            dtpStartDate.Enabled = false;
            dtpEndDate.Enabled = false;
            ExecuteSearch(recordStack: true);
        }

        private void BtnUndoSearch_Click(object? sender, EventArgs e)
        {
            // Pops search query from Stack<SearchQuery> (LIFO Stack)
            var prevQuery = _eventManager.PopPreviousSearch();
            if (prevQuery != null)
            {
                txtSearch.Text = prevQuery.Keyword;
                int catIndex = cmbCategory.Items.IndexOf(prevQuery.Category);
                cmbCategory.SelectedIndex = catIndex >= 0 ? catIndex : 0;

                if (prevQuery.StartDate.HasValue || prevQuery.EndDate.HasValue)
                {
                    chkEnableDateFilter.Checked = true;
                    _isDateFilterActive = true;
                    dtpStartDate.Enabled = true;
                    dtpEndDate.Enabled = true;
                    if (prevQuery.StartDate.HasValue) dtpStartDate.Value = prevQuery.StartDate.Value;
                    if (prevQuery.EndDate.HasValue) dtpEndDate.Value = prevQuery.EndDate.Value;
                }
                else
                {
                    chkEnableDateFilter.Checked = false;
                    _isDateFilterActive = false;
                    dtpStartDate.Enabled = false;
                    dtpEndDate.Enabled = false;
                }

                // Execute without re-pushing current to stack
                ExecuteSearch(recordStack: false);
            }
        }

        private void ChkEnableDateFilter_CheckedChanged(object? sender, EventArgs e)
        {
            _isDateFilterActive = chkEnableDateFilter.Checked;
            dtpStartDate.Enabled = _isDateFilterActive;
            dtpEndDate.Enabled = _isDateFilterActive;
        }

        private void BtnQuickFilter_Click(string filterType)
        {
            chkEnableDateFilter.Checked = true;
            _isDateFilterActive = true;
            dtpStartDate.Enabled = true;
            dtpEndDate.Enabled = true;

            switch (filterType)
            {
                case "Today":
                    dtpStartDate.Value = DateTime.Today;
                    dtpEndDate.Value = DateTime.Today;
                    break;
                case "Week":
                    dtpStartDate.Value = DateTime.Today;
                    dtpEndDate.Value = DateTime.Today.AddDays(7);
                    break;
                case "Month":
                    dtpStartDate.Value = DateTime.Today;
                    dtpEndDate.Value = DateTime.Today.AddDays(30);
                    break;
                case "All":
                    chkEnableDateFilter.Checked = false;
                    _isDateFilterActive = false;
                    dtpStartDate.Enabled = false;
                    dtpEndDate.Enabled = false;
                    break;
            }

            ExecuteSearch(recordStack: true);
        }

        // =========================================================================
        // RECOMMENDATION FEATURE (30 MARKS)
        // =========================================================================

        private void LoadRecommendations()
        {
            lblPreferenceProfile.Text = _recommendationEngine.GetPreferenceProfileSummary();

            // Uses PriorityQueue<RecommendationScore, double> inside the engine
            var recs = _recommendationEngine.GetRecommendations(topCount: 6);

            pnlRecCardsContainer.Controls.Clear();

            if (recs.Count == 0)
            {
                var lblEmpty = new Label
                {
                    Text = "No recommendations available yet. Try searching for specific categories!",
                    Font = AppTheme.SubHeadingFont,
                    ForeColor = AppTheme.MutedText,
                    Dock = DockStyle.Fill,
                    TextAlign = ContentAlignment.MiddleCenter
                };
                pnlRecCardsContainer.Controls.Add(lblEmpty);
                return;
            }

            foreach (var rec in recs)
            {
                var card = CreateRecommendationCard(rec);
                pnlRecCardsContainer.Controls.Add(card);
            }

            // Populate Preference Stats Table
            PopulatePreferenceAnalyticsTable();
        }

        private Panel CreateRecommendationCard(RecommendationScore rec)
        {
            var pnl = new Panel
            {
                Width = pnlRecCardsContainer.ClientSize.Width > 50 ? pnlRecCardsContainer.ClientSize.Width - 30 : 680,
                Height = 125,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(0, 0, 0, 12),
                Padding = new Padding(12)
            };

            // Score Badge
            var lblScore = new Label
            {
                Text = $"⭐ {rec.ScoreFormatted}",
                Font = AppTheme.SmallBoldFont,
                ForeColor = Color.White,
                BackColor = rec.Score >= 75 ? AppTheme.SuccessGreen : rec.Score >= 50 ? AppTheme.AccentBlue : AppTheme.WarningOrange,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(100, 26),
                Location = new Point(pnl.Width - 115, 12),
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };

            var lblTitle = new Label
            {
                Text = $"{rec.Event.TypeDisplay}  {rec.Event.Title}",
                Font = AppTheme.LabelBoldFont,
                ForeColor = AppTheme.DarkText,
                Location = new Point(12, 10),
                Size = new Size(pnl.Width - 140, 22),
                AutoEllipsis = true
            };

            var lblMeta = new Label
            {
                Text = $"📅 {rec.Event.FormattedDate} ({rec.Event.TimeSlot})  •  📍 {rec.Event.Location}  •  🏷 {rec.Event.Category}",
                Font = AppTheme.SmallFont,
                ForeColor = AppTheme.MutedText,
                Location = new Point(12, 34),
                Size = new Size(pnl.Width - 140, 20),
                AutoEllipsis = true
            };

            var lblReason = new Label
            {
                Text = $"💡 Why recommended: {rec.MatchReason}",
                Font = AppTheme.SmallBoldFont,
                ForeColor = AppTheme.PrimaryBlue,
                Location = new Point(12, 58),
                Size = new Size(pnl.Width - 140, 36),
                AutoEllipsis = true
            };

            var btnView = new Button
            {
                Text = "View Details",
                Size = new Size(100, 30),
                Location = new Point(pnl.Width - 115, 80),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            AppTheme.StyleSecondaryButton(btnView);
            btnView.Height = 30;
            btnView.Click += (s, e) => ShowEventDetails(rec.Event);

            pnl.Controls.Add(lblScore);
            pnl.Controls.Add(lblTitle);
            pnl.Controls.Add(lblMeta);
            pnl.Controls.Add(lblReason);
            pnl.Controls.Add(btnView);

            return pnl;
        }

        private void PopulatePreferenceAnalyticsTable()
        {
            dgvPreferences.Rows.Clear();
            int total = _eventManager.TotalSearchesCount;

            foreach (var kvp in _eventManager.CategorySearchCounts.OrderByDescending(k => k.Value))
            {
                double pct = total > 0 ? ((double)kvp.Value / total) * 100 : 0;
                dgvPreferences.Rows.Add(kvp.Key, kvp.Value, $"{pct:0.0}%");
            }
        }

        // =========================================================================
        // PRIORITY QUEUE & FIFO ANNOUNCEMENT TAB
        // =========================================================================

        private void LoadPriorityNotices()
        {
            // PriorityQueue ordering (Critical -> High -> Medium -> Low)
            var urgent = _eventManager.GetUrgentNoticesOrdered();
            dgvUrgentNotices.DataSource = null;
            dgvUrgentNotices.DataSource = urgent;

            // Announcement FIFO Queue list
            var queuedAnnouncements = _eventManager.GetAnnouncementQueue();
            lstAnnouncementQueue.Items.Clear();
            int index = 1;
            foreach (var item in queuedAnnouncements)
            {
                lstAnnouncementQueue.Items.Add($"[{index++}] [{item.Priority}] {item.Title} ({item.Category})");
            }
        }

        private void BtnRotateQueue_Click(object? sender, EventArgs e)
        {
            RefreshTicker();
            LoadPriorityNotices();
        }

        private void BtnDequeueNotice_Click(object? sender, EventArgs e)
        {
            var item = _eventManager.DequeueAnnouncement();
            if (item != null)
            {
                MessageBox.Show($"Dequeued notice: '{item.Title}'", "Queue Dequeued", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshTicker();
                LoadPriorityNotices();
            }
            else
            {
                MessageBox.Show("The announcement queue is empty.", "Queue Empty", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // =========================================================================
        // SEARCH HISTORY STACK TAB
        // =========================================================================

        private void RefreshSearchHistoryList()
        {
            lstSearchHistory.Items.Clear();
            var history = _eventManager.GetSearchHistory();
            foreach (var query in history)
            {
                lstSearchHistory.Items.Add(query.Summary);
            }
        }

        // =========================================================================
        // EVENT DETAILS & ACTION HANDLERS
        // =========================================================================

        private void ShowEventDetails(EventItem? item)
        {
            if (item == null) return;
            using var dlg = new EventDetailsDialog(item, _eventManager);
            dlg.ShowDialog(this);
            // After viewing, refresh recommendations as view history updates preference profile
            LoadRecommendations();
            UpdateStats();
        }

        private void DgvEvents_CellDoubleClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvEvents.Rows[e.RowIndex].DataBoundItem is EventItem item)
            {
                ShowEventDetails(item);
            }
        }

        private void BtnViewDetails_Click(object? sender, EventArgs e)
        {
            if (dgvEvents.SelectedRows.Count > 0 && dgvEvents.SelectedRows[0].DataBoundItem is EventItem item)
            {
                ShowEventDetails(item);
            }
            else
            {
                MessageBox.Show("Please select an event from the list to view its details.",
                    "Select Event", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnBookmark_Click(object? sender, EventArgs e)
        {
            if (dgvEvents.SelectedRows.Count > 0 && dgvEvents.SelectedRows[0].DataBoundItem is EventItem item)
            {
                _eventManager.ToggleBookmark(item.Id);
                bool isB = _eventManager.IsBookmarked(item.Id);
                MessageBox.Show($"Event '{item.Title}' has been {(isB ? "added to" : "removed from")} your bookmarks!",
                    "Bookmark Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadRecommendations();
            }
        }

        private void BtnAddEvent_Click(object? sender, EventArgs e)
        {
            using var dlg = new AddEventDialog(_eventManager);
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                PopulateCategories();
                ExecuteSearch(recordStack: true);
                LoadRecommendations();
                LoadPriorityNotices();
                RefreshTicker();
                UpdateStats();
            }
        }

        private void BtnExportCsv_Click(object? sender, EventArgs e)
        {
            var all = _eventManager.GetAllEvents();
            if (all.Count == 0)
            {
                MessageBox.Show("No events available to export.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using var sfd = new SaveFileDialog
            {
                Filter = "CSV Files (*.csv)|*.csv",
                FileName = $"MunicipalEvents_{DateTime.Now:yyyyMMdd_HHmm}.csv"
            };

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using var writer = new StreamWriter(sfd.FileName);
                    writer.WriteLine("ID,Title,Category,Date,Time,Priority,Location,Organizer,Tags,Description");
                    foreach (var ev in all)
                    {
                        writer.WriteLine($"{ev.Id},\"{EscapeCsv(ev.Title)}\",\"{EscapeCsv(ev.Category)}\",{ev.FormattedDate},\"{EscapeCsv(ev.TimeSlot)}\",{ev.Priority},\"{EscapeCsv(ev.Location)}\",\"{EscapeCsv(ev.Organizer)}\",\"{EscapeCsv(ev.TagsDisplay)}\",\"{EscapeCsv(ev.Description)}\"");
                    }
                    MessageBox.Show($"Successfully exported {all.Count} events to:\n{sfd.FileName}",
                        "CSV Export Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error exporting to CSV: {ex.Message}", "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private static string EscapeCsv(string s) => s.Replace("\"", "\"\"");

        private void DgvEvents_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgvEvents.Columns[e.ColumnIndex].Name == "colPriority" && e.Value != null)
            {
                if (Enum.TryParse<EventPriority>(e.Value.ToString(), out var priority))
                {
                    e.CellStyle!.ForeColor = AppTheme.GetPriorityColor(priority);
                    e.CellStyle.Font = AppTheme.LabelBoldFont;
                }
            }
        }

        private void BtnBackToMenu_Click(object? sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnShowArchInfo_Click(object? sender, EventArgs e)
        {
            string msg = "TECHNICAL REQUIREMENTS ARCHITECTURE (40 Marks):\n\n" +
                "1. Stacks, Queues, Priority Queues (15 Marks):\n" +
                "   • Stack<SearchQuery>: Records user search history and enables multi-level search Undo.\n" +
                "   • Stack<int>: Maintains recently viewed event history.\n" +
                "   • Queue<EventItem>: FIFO Municipal announcement bulletin ticker.\n" +
                "   • PriorityQueue<EventItem, int>: Min-Heap urgency ordering (Critical -> High -> Medium -> Low).\n\n" +
                "2. Hash Tables & Sorted Dictionaries (15 Marks):\n" +
                "   • SortedDictionary<DateTime, List<EventItem>>: Red-Black Tree maintaining chronological date ordering for efficient range scanning.\n" +
                "   • Dictionary<string, List<EventItem>>: O(1) Category hash table index.\n" +
                "   • Dictionary<int, EventItem>: O(1) primary key index.\n" +
                "   • Dictionary<string, int>: Category & Tag search frequency maps for recommendation profiling.\n\n" +
                "3. Sets (10 Marks):\n" +
                "   • HashSet<string>: Unique category registry for fast O(1) duplicate prevention and filter loading.\n" +
                "   • HashSet<DateTime>: Set of dates with active events.\n" +
                "   • HashSet<string> Tags: Event keyword sets supporting Jaccard set intersection.\n" +
                "   • HashSet<int>: User bookmarked event IDs.\n\n" +
                "RECOMMENDATION FEATURE (30 Marks):\n" +
                "   • Behavioral Preference Tracker analyzing category frequency & keyword tags.\n" +
                "   • Multi-factor scoring (Category affinity + Set Tag overlap + Date proximity + Urgency).\n" +
                "   • PriorityQueue<RecommendationScore, double> used for Top-K candidate extraction.";

            MessageBox.Show(msg, "Data Structures & Algorithm Architecture", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

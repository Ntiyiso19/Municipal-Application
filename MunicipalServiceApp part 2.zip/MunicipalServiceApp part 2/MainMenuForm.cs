﻿using MunicipalServiceApp.Data;

namespace MunicipalServiceApp
{
    /// <summary>
    /// Main menu form – the landing page of the Municipal Service Portal.
    /// Provides navigation to:
    /// 1. Report Issues
    /// 2. Local Events and Announcements (Part 2)
    /// 3. Service Status (placeholder for Part 3)
    /// </summary>
    public partial class MainMenuForm : Form
    {
        private readonly IssueRepository _repository;
        private readonly EventManager _eventManager;

        public MainMenuForm(IssueRepository repository, EventManager? eventManager = null)
        {
            _repository = repository;
            _eventManager = eventManager ?? new EventManager();
            InitializeComponent();
            ApplyStyling();
            WireEvents();
        }

        private void ApplyStyling()
        {
            lblTitle.Text = "🏛️  Municipal Service Portal";
            
            btnReportIssues.Text = "📝  Report Issues";
            AppTheme.StylePrimaryButton(btnReportIssues);

            btnLocalEvents.Text = "📅  Local Events & Announcements";
            btnLocalEvents.Enabled = true;
            AppTheme.StylePrimaryButton(btnLocalEvents);

            btnServiceStatus.Text = "🔍  Service Status  (Soon)";
            AppTheme.StyleDisabledButton(btnServiceStatus);

            btnExit.Text = "🚪  Exit Application";
            AppTheme.StyleDangerButton(btnExit);
        }

        private void WireEvents()
        {
            btnLocalEvents.Click += BtnLocalEvents_Click;
        }

        // ─── Event Handlers ──────────────────────────────────────────────────

        private void BtnReportIssues_Click(object? sender, EventArgs e)
        {
            var reportForm = new ReportIssuesForm(_repository);
            reportForm.FormClosed += (s, args) => this.Show();
            this.Hide();
            reportForm.Show();
        }

        private void BtnLocalEvents_Click(object? sender, EventArgs e)
        {
            // Open the Local Events & Announcements form and hide main menu
            var eventsForm = new LocalEventsForm(_eventManager);
            eventsForm.FormClosed += (s, args) => this.Show();
            this.Hide();
            eventsForm.Show();
        }

        private void BtnExit_Click(object? sender, EventArgs e)
        {
            var result = MessageBox.Show(
                "Are you sure you want to exit the application?",
                "Confirm Exit",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}

using MunicipalServiceApp.Data;

namespace MunicipalServiceApp
{
    /// <summary>
    /// Main menu form – the landing page of the Municipal Service Portal.
    /// Provides navigation to Report Issues (active) and placeholders for
    /// Local Events and Service Status (disabled / coming soon).
    /// </summary>
    public partial class MainMenuForm : Form
    {
        private readonly IssueRepository _repository;

        public MainMenuForm(IssueRepository repository)
        {
            _repository = repository;
            InitializeComponent();
            ApplyStyling();
        }

        private void ApplyStyling()
        {
            lblTitle.Text = "🏛️  Municipal Service Portal";
            
            btnReportIssues.Text = "📋  Report Issues";
            AppTheme.StylePrimaryButton(btnReportIssues);

            btnLocalEvents.Text = "📅  Local Events  (Soon)";
            AppTheme.StyleDisabledButton(btnLocalEvents);

            btnServiceStatus.Text = "🔍  Service Status  (Soon)";
            AppTheme.StyleDisabledButton(btnServiceStatus);

            btnExit.Text = "❌  Exit Application";
            AppTheme.StyleDangerButton(btnExit);
        }

        // ── Event Handlers ─────────────────────────────────────────────

        private void BtnReportIssues_Click(object? sender, EventArgs e)
        {
            // Open the Report Issues form and hide the main menu
            var reportForm = new ReportIssuesForm(_repository);
            reportForm.FormClosed += (s, args) => this.Show();
            this.Hide();
            reportForm.Show();
        }

        private void BtnExit_Click(object? sender, EventArgs e)
        {
            var result = MessageBox.Show(
                "Are you sure you want to exit the application?",
                "Confirm Exit",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}

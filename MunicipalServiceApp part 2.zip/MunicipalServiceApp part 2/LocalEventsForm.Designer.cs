﻿namespace MunicipalServiceApp
{
    partial class LocalEventsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlTop = new System.Windows.Forms.Panel();
            this.tlpHeader = new System.Windows.Forms.TableLayoutPanel();
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.lblSubTitle = new System.Windows.Forms.Label();
            this.lblHeaderTitle = new System.Windows.Forms.Label();
            this.pnlStats = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlStatTotal = new System.Windows.Forms.Panel();
            this.lblStatTotalVal = new System.Windows.Forms.Label();
            this.lblStatTotalLbl = new System.Windows.Forms.Label();
            this.pnlStatWeek = new System.Windows.Forms.Panel();
            this.lblStatWeekVal = new System.Windows.Forms.Label();
            this.lblStatWeekLbl = new System.Windows.Forms.Label();
            this.pnlStatAlerts = new System.Windows.Forms.Panel();
            this.lblStatAlertsVal = new System.Windows.Forms.Label();
            this.lblStatAlertsLbl = new System.Windows.Forms.Label();
            this.pnlStatSearches = new System.Windows.Forms.Panel();
            this.lblStatSearchesVal = new System.Windows.Forms.Label();
            this.lblStatSearchesLbl = new System.Windows.Forms.Label();
            
            this.pnlTicker = new System.Windows.Forms.Panel();
            this.lblTickerContent = new System.Windows.Forms.Label();
            this.btnNextTicker = new System.Windows.Forms.Button();

            this.pnlSearch = new System.Windows.Forms.Panel();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblSearchIcon = new System.Windows.Forms.Label();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.lblCategoryLbl = new System.Windows.Forms.Label();
            this.chkEnableDateFilter = new System.Windows.Forms.CheckBox();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnUndoSearch = new System.Windows.Forms.Button();
            this.btnClearFilters = new System.Windows.Forms.Button();
            this.btnAddEvent = new System.Windows.Forms.Button();
            this.flpQuickFilters = new System.Windows.Forms.FlowLayoutPanel();
            this.btnQuickAll = new System.Windows.Forms.Button();
            this.btnQuickToday = new System.Windows.Forms.Button();
            this.btnQuickWeek = new System.Windows.Forms.Button();
            this.btnQuickMonth = new System.Windows.Forms.Button();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabEvents = new System.Windows.Forms.TabPage();
            this.dgvEvents = new System.Windows.Forms.DataGridView();
            this.pnlEventsFooter = new System.Windows.Forms.Panel();
            this.lblResultCount = new System.Windows.Forms.Label();
            this.btnExportCsv = new System.Windows.Forms.Button();
            this.btnBookmark = new System.Windows.Forms.Button();
            this.btnViewDetails = new System.Windows.Forms.Button();

            this.tabRecommendations = new System.Windows.Forms.TabPage();
            this.tlpRecLayout = new System.Windows.Forms.TableLayoutPanel();
            this.pnlRecLeft = new System.Windows.Forms.Panel();
            this.lblPreferenceProfile = new System.Windows.Forms.Label();
            this.lblRecSectionTitle = new System.Windows.Forms.Label();
            this.pnlRecCardsContainer = new System.Windows.Forms.Panel();
            this.pnlRecRight = new System.Windows.Forms.Panel();
            this.lblAnalyticsTitle = new System.Windows.Forms.Label();
            this.dgvPreferences = new System.Windows.Forms.DataGridView();
            this.colPrefCat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPrefCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPrefPct = new System.Windows.Forms.DataGridViewTextBoxColumn();

            this.tabAnnouncements = new System.Windows.Forms.TabPage();
            this.tlpAnnounce = new System.Windows.Forms.TableLayoutPanel();
            this.pnlPriorityQueueSection = new System.Windows.Forms.Panel();
            this.lblPriorityQueueHeader = new System.Windows.Forms.Label();
            this.dgvUrgentNotices = new System.Windows.Forms.DataGridView();
            this.pnlFifoQueueSection = new System.Windows.Forms.Panel();
            this.lblFifoQueueHeader = new System.Windows.Forms.Label();
            this.lstAnnouncementQueue = new System.Windows.Forms.ListBox();
            this.pnlQueueActions = new System.Windows.Forms.FlowLayoutPanel();
            this.btnRotateQueue = new System.Windows.Forms.Button();
            this.btnDequeueNotice = new System.Windows.Forms.Button();

            this.tabHistory = new System.Windows.Forms.TabPage();
            this.lblHistoryTitle = new System.Windows.Forms.Label();
            this.lstSearchHistory = new System.Windows.Forms.ListBox();

            this.pnlBottom = new System.Windows.Forms.Panel();
            this.btnBackToMenu = new System.Windows.Forms.Button();
            this.btnShowArchInfo = new System.Windows.Forms.Button();
            // Setup Layout Suspensions
            this.pnlTop.SuspendLayout();
            this.tlpHeader.SuspendLayout();
            this.pnlTitle.SuspendLayout();
            this.pnlStats.SuspendLayout();
            this.pnlStatTotal.SuspendLayout();
            this.pnlStatWeek.SuspendLayout();
            this.pnlStatAlerts.SuspendLayout();
            this.pnlStatSearches.SuspendLayout();
            this.pnlTicker.SuspendLayout();
            this.pnlSearch.SuspendLayout();
            this.flpQuickFilters.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.tabEvents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEvents)).BeginInit();
            this.pnlEventsFooter.SuspendLayout();
            this.tabRecommendations.SuspendLayout();
            this.tlpRecLayout.SuspendLayout();
            this.pnlRecLeft.SuspendLayout();
            this.pnlRecRight.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPreferences)).BeginInit();
            this.tabAnnouncements.SuspendLayout();
            this.tlpAnnounce.SuspendLayout();
            this.pnlPriorityQueueSection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUrgentNotices)).BeginInit();
            this.pnlFifoQueueSection.SuspendLayout();
            this.pnlQueueActions.SuspendLayout();
            this.tabHistory.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();

            // pnlTop
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Height = 100;
            this.pnlTop.BackColor = AppTheme.PrimaryBlue;
            this.pnlTop.Controls.Add(this.tlpHeader);

            // tlpHeader
            this.tlpHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpHeader.ColumnCount = 2;
            this.tlpHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55F));
            this.tlpHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tlpHeader.Controls.Add(this.pnlTitle, 0, 0);
            this.tlpHeader.Controls.Add(this.pnlStats, 1, 0);
            this.tlpHeader.Padding = new System.Windows.Forms.Padding(16, 8, 16, 8);

            // pnlTitle
            this.pnlTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTitle.Controls.Add(this.lblSubTitle);
            this.pnlTitle.Controls.Add(this.lblHeaderTitle);

            // lblHeaderTitle
            this.lblHeaderTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHeaderTitle.Height = 44;
            this.lblHeaderTitle.Text = "🏛️  Local Events & Announcements";
            this.lblHeaderTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblHeaderTitle.ForeColor = System.Drawing.Color.White;

            // lblSubTitle
            this.lblSubTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSubTitle.Text = "Discover community gatherings, public notices, and personalized event suggestions.";
            this.lblSubTitle.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSubTitle.ForeColor = AppTheme.LightBlue;

            // pnlStats
            this.pnlStats.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlStats.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.pnlStats.Controls.Add(this.pnlStatSearches);
            this.pnlStats.Controls.Add(this.pnlStatAlerts);
            this.pnlStats.Controls.Add(this.pnlStatWeek);
            this.pnlStats.Controls.Add(this.pnlStatTotal);

            SetupStatPill(this.pnlStatTotal, this.lblStatTotalVal, this.lblStatTotalLbl, "Total Events");
            SetupStatPill(this.pnlStatWeek, this.lblStatWeekVal, this.lblStatWeekLbl, "This Week");
            SetupStatPill(this.pnlStatAlerts, this.lblStatAlertsVal, this.lblStatAlertsLbl, "Alerts");
            SetupStatPill(this.pnlStatSearches, this.lblStatSearchesVal, this.lblStatSearchesLbl, "Searches");
            // pnlTicker
            this.pnlTicker.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTicker.Height = 36;
            this.pnlTicker.BackColor = AppTheme.LightBlue;
            this.pnlTicker.Controls.Add(this.lblTickerContent);
            this.pnlTicker.Controls.Add(this.btnNextTicker);

            this.btnNextTicker.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnNextTicker.Width = 100;
            this.btnNextTicker.Text = "Next Alert ▶";
            this.btnNextTicker.Font = AppTheme.SmallBoldFont;
            this.btnNextTicker.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNextTicker.FlatAppearance.BorderSize = 0;
            this.btnNextTicker.BackColor = AppTheme.AccentBlue;
            this.btnNextTicker.ForeColor = System.Drawing.Color.White;
            this.btnNextTicker.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNextTicker.Click += (s, e) => this.RefreshTicker();

            this.lblTickerContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTickerContent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTickerContent.Padding = new System.Windows.Forms.Padding(16, 0, 8, 0);
            this.lblTickerContent.Font = AppTheme.SmallBoldFont;
            this.lblTickerContent.ForeColor = AppTheme.PrimaryBlue;

            // pnlSearch
            this.pnlSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSearch.Height = 85;
            this.pnlSearch.BackColor = System.Drawing.Color.White;
            this.pnlSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSearch.Padding = new System.Windows.Forms.Padding(14, 10, 14, 8);

            this.lblSearchIcon.Text = "🔍 Search:";
            this.lblSearchIcon.Font = AppTheme.LabelBoldFont;
            this.lblSearchIcon.Location = new System.Drawing.Point(14, 12);
            this.lblSearchIcon.Size = new System.Drawing.Size(75, 24);

            this.txtSearch.Location = new System.Drawing.Point(92, 10);
            this.txtSearch.Size = new System.Drawing.Size(260, 26);
            this.txtSearch.Font = AppTheme.LabelFont;
            this.txtSearch.KeyDown += (s, e) => { if (e.KeyCode == System.Windows.Forms.Keys.Enter) { e.SuppressKeyPress = true; ExecuteSearch(recordStack: true); } };

            this.lblCategoryLbl.Text = "Category:";
            this.lblCategoryLbl.Font = AppTheme.LabelBoldFont;
            this.lblCategoryLbl.Location = new System.Drawing.Point(365, 12);
            this.lblCategoryLbl.Size = new System.Drawing.Size(72, 24);

            this.cmbCategory.Location = new System.Drawing.Point(440, 10);
            this.cmbCategory.Size = new System.Drawing.Size(190, 26);
            this.cmbCategory.Font = AppTheme.LabelFont;
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.btnSearch.Location = new System.Drawing.Point(642, 8);
            this.btnSearch.Size = new System.Drawing.Size(95, 30);
            this.btnSearch.Text = "🔍 Search";
            AppTheme.StylePrimaryButton(this.btnSearch);
            this.btnSearch.Height = 30;
            this.btnSearch.Click += new System.EventHandler(this.BtnSearch_Click);

            this.btnUndoSearch.Location = new System.Drawing.Point(745, 8);
            this.btnUndoSearch.Size = new System.Drawing.Size(115, 30);
            this.btnUndoSearch.Text = "↺ Undo Search";
            AppTheme.StylePrimaryButton(this.btnUndoSearch);
            this.btnUndoSearch.Height = 30;
            this.btnUndoSearch.Click += new System.EventHandler(this.BtnUndoSearch_Click);

            this.btnClearFilters.Location = new System.Drawing.Point(868, 8);
            this.btnClearFilters.Size = new System.Drawing.Size(85, 30);
            this.btnClearFilters.Text = "Clear";
            AppTheme.StyleSecondaryButton(this.btnClearFilters);
            this.btnClearFilters.Height = 30;
            this.btnClearFilters.Click += new System.EventHandler(this.BtnClearFilters_Click);

            this.btnAddEvent.Location = new System.Drawing.Point(960, 8);
            this.btnAddEvent.Size = new System.Drawing.Size(110, 30);
            this.btnAddEvent.Text = "➕ New Event";
            AppTheme.StyleSuccessButton(this.btnAddEvent);
            this.btnAddEvent.Height = 30;
            this.btnAddEvent.Click += new System.EventHandler(this.BtnAddEvent_Click);

            this.chkEnableDateFilter.Text = "Filter Dates:";
            this.chkEnableDateFilter.Font = AppTheme.LabelBoldFont;
            this.chkEnableDateFilter.Location = new System.Drawing.Point(14, 48);
            this.chkEnableDateFilter.Size = new System.Drawing.Size(110, 24);
            this.chkEnableDateFilter.CheckedChanged += new System.EventHandler(this.ChkEnableDateFilter_CheckedChanged);

            this.dtpStartDate.Location = new System.Drawing.Point(130, 47);
            this.dtpStartDate.Size = new System.Drawing.Size(115, 25);
            this.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;

            this.lblToDate.Text = "to";
            this.lblToDate.Font = AppTheme.LabelFont;
            this.lblToDate.Location = new System.Drawing.Point(252, 49);
            this.lblToDate.Size = new System.Drawing.Size(25, 20);

            this.dtpEndDate.Location = new System.Drawing.Point(280, 47);
            this.dtpEndDate.Size = new System.Drawing.Size(115, 25);
            this.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;

            this.flpQuickFilters.Location = new System.Drawing.Point(410, 45);
            this.flpQuickFilters.Size = new System.Drawing.Size(660, 32);
            this.flpQuickFilters.FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight;

            SetupFilterChip(this.btnQuickAll, "All Dates", () => BtnQuickFilter_Click("All"));
            SetupFilterChip(this.btnQuickToday, "Today", () => BtnQuickFilter_Click("Today"));
            SetupFilterChip(this.btnQuickWeek, "Next 7 Days", () => BtnQuickFilter_Click("Week"));
            SetupFilterChip(this.btnQuickMonth, "This Month", () => BtnQuickFilter_Click("Month"));

            this.flpQuickFilters.Controls.Add(this.btnQuickAll);
            this.flpQuickFilters.Controls.Add(this.btnQuickToday);
            this.flpQuickFilters.Controls.Add(this.btnQuickWeek);
            this.flpQuickFilters.Controls.Add(this.btnQuickMonth);

            this.pnlSearch.Controls.Add(this.lblSearchIcon);
            this.pnlSearch.Controls.Add(this.txtSearch);
            this.pnlSearch.Controls.Add(this.lblCategoryLbl);
            this.pnlSearch.Controls.Add(this.cmbCategory);
            this.pnlSearch.Controls.Add(this.btnSearch);
            this.pnlSearch.Controls.Add(this.btnUndoSearch);
            this.pnlSearch.Controls.Add(this.btnClearFilters);
            this.pnlSearch.Controls.Add(this.btnAddEvent);
            this.pnlSearch.Controls.Add(this.chkEnableDateFilter);
            this.pnlSearch.Controls.Add(this.dtpStartDate);
            this.pnlSearch.Controls.Add(this.lblToDate);
            this.pnlSearch.Controls.Add(this.dtpEndDate);
            this.pnlSearch.Controls.Add(this.flpQuickFilters);
            // tabMain
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Font = AppTheme.LabelBoldFont;
            this.tabMain.Padding = new System.Drawing.Point(14, 6);
            this.tabMain.Controls.Add(this.tabEvents);
            this.tabMain.Controls.Add(this.tabRecommendations);
            this.tabMain.Controls.Add(this.tabAnnouncements);
            this.tabMain.Controls.Add(this.tabHistory);

            // Tab 1
            this.tabEvents.Text = "📅 Event Explorer";
            this.tabEvents.Padding = new System.Windows.Forms.Padding(8);
            this.tabEvents.Controls.Add(this.dgvEvents);
            this.tabEvents.Controls.Add(this.pnlEventsFooter);

            this.dgvEvents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEvents.BackgroundColor = System.Drawing.Color.White;
            this.dgvEvents.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvEvents.RowHeadersVisible = false;
            this.dgvEvents.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEvents.MultiSelect = false;
            this.dgvEvents.AllowUserToAddRows = false;
            this.dgvEvents.AllowUserToDeleteRows = false;
            this.dgvEvents.ReadOnly = true;
            this.dgvEvents.RowTemplate.Height = 32;
            this.dgvEvents.AutoGenerateColumns = false;
            this.dgvEvents.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvEvents_CellDoubleClick);
            this.dgvEvents.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DgvEvents_CellFormatting);
            ConfigureEventGridColumns(this.dgvEvents);

            this.pnlEventsFooter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlEventsFooter.Height = 44;
            this.pnlEventsFooter.BackColor = AppTheme.WhiteBg;
            this.pnlEventsFooter.Controls.Add(this.lblResultCount);
            this.pnlEventsFooter.Controls.Add(this.btnExportCsv);
            this.pnlEventsFooter.Controls.Add(this.btnBookmark);
            this.pnlEventsFooter.Controls.Add(this.btnViewDetails);

            this.lblResultCount.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblResultCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblResultCount.Font = AppTheme.SmallBoldFont;
            this.lblResultCount.ForeColor = AppTheme.MutedText;
            this.lblResultCount.Width = 520;

            this.btnExportCsv.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnExportCsv.Width = 140;
            this.btnExportCsv.Text = "📊 Export CSV";
            AppTheme.StyleSecondaryButton(this.btnExportCsv);
            this.btnExportCsv.Height = 36;
            this.btnExportCsv.Click += new System.EventHandler(this.BtnExportCsv_Click);

            this.btnBookmark.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnBookmark.Width = 135;
            this.btnBookmark.Text = "⭐ Bookmark";
            AppTheme.StyleSecondaryButton(this.btnBookmark);
            this.btnBookmark.Height = 36;
            this.btnBookmark.Click += new System.EventHandler(this.BtnBookmark_Click);

            this.btnViewDetails.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnViewDetails.Width = 140;
            this.btnViewDetails.Text = "🔍 View Details";
            AppTheme.StylePrimaryButton(this.btnViewDetails);
            this.btnViewDetails.Height = 36;
            this.btnViewDetails.Click += new System.EventHandler(this.BtnViewDetails_Click);

            // Tab 2: Recommendations
            this.tabRecommendations.Text = "⭐ Recommended For You";
            this.tabRecommendations.Padding = new System.Windows.Forms.Padding(10);
            this.tabRecommendations.Controls.Add(this.tlpRecLayout);

            this.tlpRecLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpRecLayout.ColumnCount = 2;
            this.tlpRecLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65F));
            this.tlpRecLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tlpRecLayout.Controls.Add(this.pnlRecLeft, 0, 0);
            this.tlpRecLayout.Controls.Add(this.pnlRecRight, 1, 0);

            this.pnlRecLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRecLeft.Controls.Add(this.pnlRecCardsContainer);
            this.pnlRecLeft.Controls.Add(this.lblPreferenceProfile);
            this.pnlRecLeft.Controls.Add(this.lblRecSectionTitle);

            this.lblRecSectionTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblRecSectionTitle.Height = 28;
            this.lblRecSectionTitle.Text = "Suggestions Ranked By Content Affinity & PriorityQueue";
            this.lblRecSectionTitle.Font = AppTheme.LabelBoldFont;
            this.lblRecSectionTitle.ForeColor = AppTheme.PrimaryBlue;

            this.lblPreferenceProfile.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblPreferenceProfile.Height = 38;
            this.lblPreferenceProfile.Font = AppTheme.SmallFont;
            this.lblPreferenceProfile.ForeColor = AppTheme.DarkText;
            this.lblPreferenceProfile.BackColor = AppTheme.LightBlue;
            this.lblPreferenceProfile.Padding = new System.Windows.Forms.Padding(8, 6, 8, 6);

            this.pnlRecCardsContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRecCardsContainer.AutoScroll = true;
            this.pnlRecCardsContainer.Padding = new System.Windows.Forms.Padding(0, 10, 8, 0);

            this.pnlRecRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRecRight.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.pnlRecRight.Controls.Add(this.dgvPreferences);
            this.pnlRecRight.Controls.Add(this.lblAnalyticsTitle);

            this.lblAnalyticsTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblAnalyticsTitle.Height = 28;
            this.lblAnalyticsTitle.Text = "📊 Your Search Analytics";
            this.lblAnalyticsTitle.Font = AppTheme.LabelBoldFont;
            this.lblAnalyticsTitle.ForeColor = AppTheme.PrimaryBlue;

            this.dgvPreferences.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPreferences.BackgroundColor = System.Drawing.Color.White;
            this.dgvPreferences.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dgvPreferences.RowHeadersVisible = false;
            this.dgvPreferences.AllowUserToAddRows = false;
            this.dgvPreferences.AllowUserToDeleteRows = false;
            this.dgvPreferences.ReadOnly = true;
            this.dgvPreferences.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPreferences.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[]
            {
                this.colPrefCat,
                this.colPrefCount,
                this.colPrefPct
            });

            this.colPrefCat.HeaderText = "Category";
            this.colPrefCat.Width = 160;
            this.colPrefCount.HeaderText = "Count";
            this.colPrefCount.Width = 65;
            this.colPrefPct.HeaderText = "Share";
            this.colPrefPct.Width = 70;
            // Tab 3: Announcements
            this.tabAnnouncements.Text = "📢 Urgent Alerts & Queues";
            this.tabAnnouncements.Padding = new System.Windows.Forms.Padding(10);
            this.tabAnnouncements.Controls.Add(this.tlpAnnounce);

            this.tlpAnnounce.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpAnnounce.ColumnCount = 2;
            this.tlpAnnounce.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55F));
            this.tlpAnnounce.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tlpAnnounce.Controls.Add(this.pnlPriorityQueueSection, 0, 0);
            this.tlpAnnounce.Controls.Add(this.pnlFifoQueueSection, 1, 0);

            this.pnlPriorityQueueSection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPriorityQueueSection.Controls.Add(this.dgvUrgentNotices);
            this.pnlPriorityQueueSection.Controls.Add(this.lblPriorityQueueHeader);

            this.lblPriorityQueueHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblPriorityQueueHeader.Height = 36;
            this.lblPriorityQueueHeader.Text = "⚡ PriorityQueue<EventItem, int> (Critical First Min-Heap)";
            this.lblPriorityQueueHeader.Font = AppTheme.LabelBoldFont;
            this.lblPriorityQueueHeader.ForeColor = AppTheme.DangerRed;

            this.dgvUrgentNotices.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvUrgentNotices.BackgroundColor = System.Drawing.Color.White;
            this.dgvUrgentNotices.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dgvUrgentNotices.RowHeadersVisible = false;
            this.dgvUrgentNotices.AllowUserToAddRows = false;
            this.dgvUrgentNotices.ReadOnly = true;
            this.dgvUrgentNotices.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUrgentNotices.AutoGenerateColumns = false;
            ConfigureUrgentGridColumns(this.dgvUrgentNotices);

            this.pnlFifoQueueSection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFifoQueueSection.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.pnlFifoQueueSection.Controls.Add(this.lstAnnouncementQueue);
            this.pnlFifoQueueSection.Controls.Add(this.pnlQueueActions);
            this.pnlFifoQueueSection.Controls.Add(this.lblFifoQueueHeader);

            this.lblFifoQueueHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblFifoQueueHeader.Height = 36;
            this.lblFifoQueueHeader.Text = "📋 Queue<EventItem> (FIFO Announcement Bulletin)";
            this.lblFifoQueueHeader.Font = AppTheme.LabelBoldFont;
            this.lblFifoQueueHeader.ForeColor = AppTheme.PrimaryBlue;

            this.lstAnnouncementQueue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstAnnouncementQueue.Font = AppTheme.LabelFont;
            this.lstAnnouncementQueue.ItemHeight = 20;

            this.pnlQueueActions.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlQueueActions.Height = 44;
            this.pnlQueueActions.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;

            this.btnDequeueNotice.Text = "Dequeue Notice";
            this.btnDequeueNotice.Size = new System.Drawing.Size(140, 36);
            AppTheme.StyleSecondaryButton(this.btnDequeueNotice);
            this.btnDequeueNotice.Click += new System.EventHandler(this.BtnDequeueNotice_Click);

            this.btnRotateQueue.Text = "Rotate / Next";
            this.btnRotateQueue.Size = new System.Drawing.Size(130, 36);
            AppTheme.StylePrimaryButton(this.btnRotateQueue);
            this.btnRotateQueue.Click += new System.EventHandler(this.BtnRotateQueue_Click);

            this.pnlQueueActions.Controls.Add(this.btnDequeueNotice);
            this.pnlQueueActions.Controls.Add(this.btnRotateQueue);

            // Tab 4: History Stack
            this.tabHistory.Text = "🕒 Search History Stack";
            this.tabHistory.Padding = new System.Windows.Forms.Padding(14);
            this.tabHistory.Controls.Add(this.lstSearchHistory);
            this.tabHistory.Controls.Add(this.lblHistoryTitle);

            this.lblHistoryTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHistoryTitle.Height = 40;
            this.lblHistoryTitle.Text = "Stack<SearchQuery> (LIFO Multi-Level Search History & Undo Tracker)";
            this.lblHistoryTitle.Font = AppTheme.LabelBoldFont;
            this.lblHistoryTitle.ForeColor = AppTheme.PrimaryBlue;

            this.lstSearchHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstSearchHistory.Font = AppTheme.LabelFont;
            this.lstSearchHistory.ItemHeight = 22;

            // pnlBottom
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Height = 52;
            this.pnlBottom.BackColor = AppTheme.WhiteBg;
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Padding = new System.Windows.Forms.Padding(14, 8, 14, 8);
            this.pnlBottom.Controls.Add(this.btnBackToMenu);
            this.pnlBottom.Controls.Add(this.btnShowArchInfo);

            this.btnBackToMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnBackToMenu.Width = 180;
            this.btnBackToMenu.Text = "⬅ Back to Main Menu";
            AppTheme.StyleSecondaryButton(this.btnBackToMenu);
            this.btnBackToMenu.Height = 36;
            this.btnBackToMenu.Click += new System.EventHandler(this.BtnBackToMenu_Click);

            this.btnShowArchInfo.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnShowArchInfo.Width = 260;
            this.btnShowArchInfo.Text = "ℹ️ Data Structures Info";
            AppTheme.StylePrimaryButton(this.btnShowArchInfo);
            this.btnShowArchInfo.Height = 36;
            this.btnShowArchInfo.Click += new System.EventHandler(this.BtnShowArchInfo_Click);

            // Main Form Setup
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 750);
            this.MinimumSize = new System.Drawing.Size(1000, 680);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Municipal Service Portal — Local Events & Announcements";

            this.Controls.Add(this.tabMain);
            this.Controls.Add(this.pnlSearch);
            this.Controls.Add(this.pnlTicker);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.pnlBottom);

            // Resume Layouts
            this.pnlTop.ResumeLayout(false);
            this.tlpHeader.ResumeLayout(false);
            this.pnlTitle.ResumeLayout(false);
            this.pnlStats.ResumeLayout(false);
            this.pnlStatTotal.ResumeLayout(false);
            this.pnlStatWeek.ResumeLayout(false);
            this.pnlStatAlerts.ResumeLayout(false);
            this.pnlStatSearches.ResumeLayout(false);
            this.pnlTicker.ResumeLayout(false);
            this.pnlSearch.ResumeLayout(false);
            this.pnlSearch.PerformLayout();
            this.flpQuickFilters.ResumeLayout(false);
            this.tabMain.ResumeLayout(false);
            this.tabEvents.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEvents)).EndInit();
            this.pnlEventsFooter.ResumeLayout(false);
            this.tabRecommendations.ResumeLayout(false);
            this.tlpRecLayout.ResumeLayout(false);
            this.pnlRecLeft.ResumeLayout(false);
            this.pnlRecRight.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPreferences)).EndInit();
            this.tabAnnouncements.ResumeLayout(false);
            this.tlpAnnounce.ResumeLayout(false);
            this.pnlPriorityQueueSection.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUrgentNotices)).EndInit();
            this.pnlFifoQueueSection.ResumeLayout(false);
            this.pnlQueueActions.ResumeLayout(false);
            this.tabHistory.ResumeLayout(false);
            this.pnlBottom.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private void SetupStatPill(System.Windows.Forms.Panel pnl, System.Windows.Forms.Label lblVal, System.Windows.Forms.Label lblLbl, string labelText)
        {
            pnl.Size = new System.Drawing.Size(95, 70);
            pnl.BackColor = System.Drawing.Color.FromArgb(40, System.Drawing.Color.White);
            pnl.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);

            lblVal.Dock = System.Windows.Forms.DockStyle.Top;
            lblVal.Height = 40;
            lblVal.Font = AppTheme.LargeStatFont;
            lblVal.ForeColor = System.Drawing.Color.White;
            lblVal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            lblVal.Text = "0";

            lblLbl.Dock = System.Windows.Forms.DockStyle.Bottom;
            lblLbl.Height = 24;
            lblLbl.Font = AppTheme.SmallFont;
            lblLbl.ForeColor = AppTheme.LightBlue;
            lblLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            lblLbl.Text = labelText;

            pnl.Controls.Add(lblVal);
            pnl.Controls.Add(lblLbl);
        }

        private void SetupFilterChip(System.Windows.Forms.Button btn, string text, Action onClick)
        {
            btn.Text = text;
            btn.Font = AppTheme.SmallBoldFont;
            btn.Size = new System.Drawing.Size(125, 28);
            btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn.FlatAppearance.BorderColor = AppTheme.BorderColor;
            btn.BackColor = AppTheme.SoftGray;
            btn.ForeColor = AppTheme.DarkText;
            btn.Cursor = System.Windows.Forms.Cursors.Hand;
            btn.Click += (s, e) => onClick();
        }

        private void ConfigureEventGridColumns(System.Windows.Forms.DataGridView dgv)
        {
            dgv.Columns.Clear();
            dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[]
            {
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colType", DataPropertyName = "TypeDisplay", HeaderText = "Type", Width = 115 },
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colPriority", DataPropertyName = "PriorityDisplay", HeaderText = "Priority", Width = 90 },
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colDate", DataPropertyName = "FormattedDate", HeaderText = "Date", Width = 100 },
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colTitle", DataPropertyName = "Title", HeaderText = "Title", Width = 230, AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill },
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colCategory", DataPropertyName = "Category", HeaderText = "Category", Width = 175 },
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colLocation", DataPropertyName = "Location", HeaderText = "Location / Venue", Width = 190 },
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colTime", DataPropertyName = "TimeSlot", HeaderText = "Time", Width = 115 }
            });
        }

        private void ConfigureUrgentGridColumns(System.Windows.Forms.DataGridView dgv)
        {
            dgv.Columns.Clear();
            dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[]
            {
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colUrgPriority", DataPropertyName = "PriorityDisplay", HeaderText = "Priority", Width = 85 },
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colUrgDate", DataPropertyName = "FormattedDate", HeaderText = "Date", Width = 95 },
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colUrgTitle", DataPropertyName = "Title", HeaderText = "Title", Width = 220, AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill },
                new System.Windows.Forms.DataGridViewTextBoxColumn { Name = "colUrgCat", DataPropertyName = "Category", HeaderText = "Category", Width = 150 }
            });
        }

        private void ApplyCustomStyling()
        {
            this.Font = AppTheme.LabelFont;
        }

        #endregion

        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TableLayoutPanel tlpHeader;
        private System.Windows.Forms.Panel pnlTitle;
        private System.Windows.Forms.Label lblHeaderTitle;
        private System.Windows.Forms.Label lblSubTitle;
        private System.Windows.Forms.FlowLayoutPanel pnlStats;
        private System.Windows.Forms.Panel pnlStatTotal;
        private System.Windows.Forms.Label lblStatTotalVal;
        private System.Windows.Forms.Label lblStatTotalLbl;
        private System.Windows.Forms.Panel pnlStatWeek;
        private System.Windows.Forms.Label lblStatWeekVal;
        private System.Windows.Forms.Label lblStatWeekLbl;
        private System.Windows.Forms.Panel pnlStatAlerts;
        private System.Windows.Forms.Label lblStatAlertsVal;
        private System.Windows.Forms.Label lblStatAlertsLbl;
        private System.Windows.Forms.Panel pnlStatSearches;
        private System.Windows.Forms.Label lblStatSearchesVal;
        private System.Windows.Forms.Label lblStatSearchesLbl;

        private System.Windows.Forms.Panel pnlTicker;
        private System.Windows.Forms.Label lblTickerContent;
        private System.Windows.Forms.Button btnNextTicker;

        private System.Windows.Forms.Panel pnlSearch;
        private System.Windows.Forms.Label lblSearchIcon;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblCategoryLbl;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnUndoSearch;
        private System.Windows.Forms.Button btnClearFilters;
        private System.Windows.Forms.Button btnAddEvent;
        private System.Windows.Forms.CheckBox chkEnableDateFilter;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.FlowLayoutPanel flpQuickFilters;
        private System.Windows.Forms.Button btnQuickAll;
        private System.Windows.Forms.Button btnQuickToday;
        private System.Windows.Forms.Button btnQuickWeek;
        private System.Windows.Forms.Button btnQuickMonth;

        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabEvents;
        private System.Windows.Forms.DataGridView dgvEvents;
        private System.Windows.Forms.Panel pnlEventsFooter;
        private System.Windows.Forms.Label lblResultCount;
        private System.Windows.Forms.Button btnExportCsv;
        private System.Windows.Forms.Button btnBookmark;
        private System.Windows.Forms.Button btnViewDetails;

        private System.Windows.Forms.TabPage tabRecommendations;
        private System.Windows.Forms.TableLayoutPanel tlpRecLayout;
        private System.Windows.Forms.Panel pnlRecLeft;
        private System.Windows.Forms.Label lblRecSectionTitle;
        private System.Windows.Forms.Label lblPreferenceProfile;
        private System.Windows.Forms.Panel pnlRecCardsContainer;
        private System.Windows.Forms.Panel pnlRecRight;
        private System.Windows.Forms.Label lblAnalyticsTitle;
        private System.Windows.Forms.DataGridView dgvPreferences;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrefCat;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrefCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrefPct;

        private System.Windows.Forms.TabPage tabAnnouncements;
        private System.Windows.Forms.TableLayoutPanel tlpAnnounce;
        private System.Windows.Forms.Panel pnlPriorityQueueSection;
        private System.Windows.Forms.Label lblPriorityQueueHeader;
        private System.Windows.Forms.DataGridView dgvUrgentNotices;
        private System.Windows.Forms.Panel pnlFifoQueueSection;
        private System.Windows.Forms.Label lblFifoQueueHeader;
        private System.Windows.Forms.ListBox lstAnnouncementQueue;
        private System.Windows.Forms.FlowLayoutPanel pnlQueueActions;
        private System.Windows.Forms.Button btnRotateQueue;
        private System.Windows.Forms.Button btnDequeueNotice;

        private System.Windows.Forms.TabPage tabHistory;
        private System.Windows.Forms.Label lblHistoryTitle;
        private System.Windows.Forms.ListBox lstSearchHistory;

        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Button btnBackToMenu;
        private System.Windows.Forms.Button btnShowArchInfo;
    }
}
